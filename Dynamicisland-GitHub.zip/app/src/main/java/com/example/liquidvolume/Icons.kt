package com.example.liquidvolume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/**
 * Ikon vektor bergaya SF Symbols (garis tipis, ujung membulat), digambar sendiri.
 * Menggantikan emoji / karakter teks supaya tampilannya sama di semua HP dan tidak jadul.
 *
 * Kunci ikon: lock, unlock, check, checkcircle, bolt, link, headphones, bell, bellslash, vibrate,
 * torch, music, timer, nav, phone, rec, down, up, updown, gauge, stop, close, pause, play, mic,
 * power, send, chevup, chevdown, home, sliders, grid, gear
 */
class IconView(ctx: Context, private var kind: String, private var color: Int, sizeDp: Float = 18f) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val sizePx = (sizeDp * d).toInt()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val p = Path()
    private val r = RectF()

    fun set(kind: String, color: Int) { this.kind = kind; this.color = color; invalidate() }
    fun tint(color: Int) { this.color = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(
            resolveSize(sizePx + paddingLeft + paddingRight, w),
            resolveSize(sizePx + paddingTop + paddingBottom, h))
    }

    override fun onDraw(c: Canvas) {
        val cw = width - paddingLeft - paddingRight
        val ch = height - paddingTop - paddingBottom
        val s = minOf(cw, ch).toFloat()
        if (s <= 0f) return
        stroke.color = color; fill.color = color
        stroke.strokeWidth = 0.085f; fill.strokeWidth = 0.04f
        c.save()
        c.translate(paddingLeft + cw / 2f, paddingTop + ch / 2f)
        c.scale(s, s)
        glyph(c)
        c.restore()
    }

    private fun ln(c: Canvas, a: Float, b: Float, x: Float, y: Float) = c.drawLine(a, b, x, y, stroke)

    private fun poly(c: Canvas, closed: Boolean, filled: Boolean, vararg v: Float) {
        p.reset()
        p.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { p.lineTo(v[i], v[i + 1]); i += 2 }
        if (closed) p.close()
        c.drawPath(p, if (filled) fill else stroke)
    }

    private fun rrect(c: Canvas, l: Float, t: Float, rt: Float, b: Float, rad: Float, paint: Paint) {
        r.set(l, t, rt, b)
        c.drawRoundRect(r, rad, rad, paint)
    }

    private fun bell(c: Canvas) {
        p.reset()
        r.set(-.24f, -.38f, .24f, .10f)
        p.arcTo(r, 180f, 180f)
        p.lineTo(.32f, .22f); p.lineTo(-.32f, .22f); p.close()
        c.drawPath(p, fill)
        c.drawCircle(0f, .33f, .07f, fill)
        c.drawCircle(0f, -.40f, .04f, fill)
    }

    private fun glyph(c: Canvas) {
        when (kind) {
            "check" -> {
                stroke.strokeWidth = 0.11f
                poly(c, false, false, -.30f, .02f, -.08f, .24f, .32f, -.22f)
            }
            "checkcircle" -> {
                r.set(-.40f, -.40f, .40f, .40f); c.drawOval(r, stroke)
                stroke.strokeWidth = 0.09f
                poly(c, false, false, -.20f, 0f, -.06f, .14f, .22f, -.14f)
            }
            "lock", "unlock" -> {
                rrect(c, -.28f, -.04f, .28f, .40f, .08f, fill)
                p.reset()
                p.moveTo(-.17f, -.04f); p.lineTo(-.17f, -.26f)
                r.set(-.17f, -.42f, .17f, -.10f)
                p.arcTo(r, 180f, 180f)
                p.lineTo(.17f, if (kind == "lock") -.04f else -.15f)
                c.drawPath(p, stroke)
            }
            "bolt" -> poly(c, true, true, .08f, -.46f, -.26f, .06f, -.02f, .06f, -.10f, .46f, .26f, -.10f, .02f, -.10f)
            "link" -> {
                c.save(); c.rotate(-45f)
                rrect(c, -.46f, -.15f, .06f, .15f, .15f, stroke)
                rrect(c, -.06f, -.15f, .46f, .15f, .15f, stroke)
                c.restore()
            }
            "headphones" -> {
                p.reset(); r.set(-.34f, -.36f, .34f, .32f); p.arcTo(r, 180f, 180f); c.drawPath(p, stroke)
                rrect(c, -.42f, -.02f, -.24f, .30f, .07f, fill)
                rrect(c, .24f, -.02f, .42f, .30f, .07f, fill)
            }
            "bell" -> bell(c)
            "bellslash" -> {
                bell(c)
                stroke.strokeWidth = 0.09f
                ln(c, -.40f, -.40f, .40f, .42f)
            }
            "vibrate" -> {
                rrect(c, -.14f, -.30f, .14f, .30f, .06f, stroke)
                ln(c, -.30f, -.12f, -.30f, .12f); ln(c, .30f, -.12f, .30f, .12f)
                ln(c, -.42f, -.05f, -.42f, .05f); ln(c, .42f, -.05f, .42f, .05f)
            }
            "torch" -> {
                poly(c, true, true, -.18f, -.42f, .18f, -.42f, .12f, -.20f, -.12f, -.20f)
                rrect(c, -.12f, -.14f, .12f, .42f, .06f, stroke)
                rrect(c, -.03f, 0f, .03f, .12f, .03f, fill)
            }
            "music" -> {
                c.drawCircle(-.06f, .30f, .14f, fill)
                ln(c, .08f, .30f, .08f, -.36f)
                p.reset(); p.moveTo(.08f, -.36f); p.quadTo(.14f, -.14f, .34f, -.10f); c.drawPath(p, stroke)
            }
            "timer" -> {
                c.drawCircle(0f, .06f, .34f, stroke)
                ln(c, -.10f, -.40f, .10f, -.40f)
                ln(c, 0f, .06f, .14f, -.08f)
            }
            "nav" -> poly(c, true, true, .36f, -.36f, -.32f, -.02f, -.02f, .04f, .04f, .34f)
            "phone" -> {
                stroke.strokeWidth = 0.15f
                p.reset(); p.moveTo(-.30f, -.30f); p.cubicTo(-.38f, .10f, 0f, .38f, .30f, .30f)
                c.drawPath(p, stroke)
            }
            "rec" -> c.drawCircle(0f, 0f, .26f, fill)
            "down" -> {
                ln(c, 0f, -.34f, 0f, .30f)
                poly(c, false, false, -.22f, .08f, 0f, .32f, .22f, .08f)
            }
            "up", "send" -> {
                ln(c, 0f, .34f, 0f, -.30f)
                poly(c, false, false, -.22f, -.08f, 0f, -.32f, .22f, -.08f)
            }
            "updown" -> {
                ln(c, -.16f, .30f, -.16f, -.30f)
                poly(c, false, false, -.34f, -.12f, -.16f, -.32f, .02f, -.12f)
                ln(c, .16f, -.30f, .16f, .30f)
                poly(c, false, false, -.02f, .12f, .16f, .32f, .34f, .12f)
            }
            "gauge" -> {
                p.reset(); r.set(-.38f, -.38f, .38f, .38f); p.arcTo(r, 150f, 240f); c.drawPath(p, stroke)
                ln(c, 0f, 0f, .18f, -.20f)
                c.drawCircle(0f, 0f, .06f, fill)
            }
            "plane" -> {
                c.rotate(45f)
                poly(c, true, true, 0f, -.44f, .07f, -.28f, .07f, -.10f, .42f, .10f, .42f, .20f, .07f, .10f,
                    .07f, .28f, .18f, .36f, .18f, .42f, 0f, .38f, -.18f, .42f, -.18f, .36f, -.07f, .28f,
                    -.07f, .10f, -.42f, .20f, -.42f, .10f, -.07f, -.10f, -.07f, -.28f)
            }
            "wifi" -> {
                c.translate(0f, -.06f)
                for (rad in floatArrayOf(.16f, .32f, .48f)) {
                    p.reset(); r.set(-rad, .30f - rad, rad, .30f + rad); p.arcTo(r, -135f, 90f); c.drawPath(p, stroke)
                }
                c.drawCircle(0f, .30f, .05f, fill)
            }
            "bluetooth" -> poly(c, false, false, -.22f, -.16f, .22f, .18f, 0f, .38f, 0f, -.38f, .22f, -.18f, -.22f, .16f)
            "thermo" -> {
                rrect(c, -.08f, -.42f, .08f, .12f, .08f, stroke)
                c.drawCircle(0f, .26f, .16f, fill)
                ln(c, 0f, .10f, 0f, -.20f)
            }
            "stop" -> rrect(c, -.26f, -.26f, .26f, .26f, .06f, fill)
            "close" -> {
                ln(c, -.26f, -.26f, .26f, .26f); ln(c, .26f, -.26f, -.26f, .26f)
            }
            "pause" -> {
                rrect(c, -.24f, -.28f, -.06f, .28f, .05f, fill)
                rrect(c, .06f, -.28f, .24f, .28f, .05f, fill)
            }
            "play" -> poly(c, true, true, -.18f, -.30f, .32f, 0f, -.18f, .30f)
            "mic" -> {
                rrect(c, -.12f, -.38f, .12f, .08f, .12f, fill)
                p.reset(); r.set(-.26f, -.20f, .26f, .28f); p.arcTo(r, 0f, 180f); c.drawPath(p, stroke)
                ln(c, 0f, .28f, 0f, .42f)
            }
            "power" -> {
                p.reset(); r.set(-.30f, -.28f, .30f, .32f); p.arcTo(r, -60f, 300f); c.drawPath(p, stroke)
                ln(c, 0f, -.42f, 0f, -.06f)
            }
            "chevup" -> poly(c, false, false, -.26f, .12f, 0f, -.14f, .26f, .12f)
            "chevdown" -> poly(c, false, false, -.26f, -.12f, 0f, .14f, .26f, -.12f)
            "home" -> {
                poly(c, false, false, -.40f, -.02f, 0f, -.38f, .40f, -.02f)
                poly(c, false, false, -.28f, -.08f, -.28f, .36f, .28f, .36f, .28f, -.08f)
            }
            "sliders" -> {
                val ys = floatArrayOf(-.24f, 0f, .24f)
                val xs = floatArrayOf(-.14f, .16f, -.06f)
                for (i in 0..2) {
                    ln(c, -.38f, ys[i], .38f, ys[i])
                    c.drawCircle(xs[i], ys[i], .10f, fill)
                }
            }
            "grid" -> {
                rrect(c, -.36f, -.36f, -.04f, -.04f, .07f, stroke)
                rrect(c, .04f, -.36f, .36f, -.04f, .07f, stroke)
                rrect(c, -.36f, .04f, -.04f, .36f, .07f, stroke)
                rrect(c, .04f, .04f, .36f, .36f, .07f, stroke)
            }
            "gear" -> {
                c.drawCircle(0f, 0f, .24f, stroke)
                c.drawCircle(0f, 0f, .08f, stroke)
                stroke.strokeWidth = 0.13f
                for (k in 0 until 8) {
                    c.save(); c.rotate(k * 45f)
                    ln(c, 0f, -.31f, 0f, -.40f)
                    c.restore()
                }
            }
            else -> c.drawCircle(0f, 0f, .2f, fill)
        }
    }
}
