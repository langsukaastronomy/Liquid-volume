package com.example.liquidvolume

import android.content.Context

object Prefs {
    const val BLURIFY = 0
    const val LIQUID = 1
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun style(c: Context) = sp(c).getInt("style", LIQUID)
    fun setStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun blur(c: Context) = sp(c).getBoolean("blur2", true)
    fun setBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean("blur2", v).apply()
    fun islandOn(c: Context) = sp(c).getBoolean("island", true)
    fun setIslandOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("island", v).apply()
    fun islandIdle(c: Context) = sp(c).getBoolean("idle", true)
    fun setIslandIdle(c: Context, v: Boolean) = sp(c).edit().putBoolean("idle", v).apply()
    fun islandGlass(c: Context) = sp(c).getBoolean("iglass", false)
    fun setIslandGlass(c: Context, v: Boolean) = sp(c).edit().putBoolean("iglass", v).apply()
    fun adj(c: Context, k: String) = sp(c).getInt(k, 0)
    fun setAdj(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun ccOn(c: Context) = sp(c).getBoolean("ccOn", true)
    fun setCcOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("ccOn", v).apply()
    fun ccSide(c: Context) = sp(c).getInt("ccSide", 0)
    fun setCcSide(c: Context, v: Int) = sp(c).edit().putInt("ccSide", v).apply()
    fun ccGlass(c: Context) = sp(c).getBoolean("ccGlass", true)
    fun setCcGlass(c: Context, v: Boolean) = sp(c).edit().putBoolean("ccGlass", v).apply()
    fun ccMix(c: Context) = sp(c).getInt("ccMix", 2)
    fun setCcMix(c: Context, v: Int) = sp(c).edit().putInt("ccMix", v).apply()
    fun ccLine(c: Context) = sp(c).getInt("ccLine", 1)
    fun setCcLine(c: Context, v: Int) = sp(c).edit().putInt("ccLine", v).apply()
    fun ccTheme(c: Context) = sp(c).getInt("ccTheme", 0)
    fun setCcTheme(c: Context, v: Int) = sp(c).edit().putInt("ccTheme", v).apply()
    fun ccBlur(c: Context) = sp(c).getBoolean("ccBlur", true)
    fun setCcBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean("ccBlur", v).apply()
    fun ccRadius(c: Context) = sp(c).getInt("ccRadius", 28)
    fun setCcRadius(c: Context, v: Int) = sp(c).edit().putInt("ccRadius", v).apply()
    fun ccSize(c: Context) = sp(c).getInt("ccSize", 1)
    fun setCcSize(c: Context, v: Int) = sp(c).edit().putInt("ccSize", v).apply()
    fun ccPct(c: Context) = sp(c).getBoolean("ccPct", true)
    fun setCcPct(c: Context, v: Boolean) = sp(c).edit().putBoolean("ccPct", v).apply()
    fun ccStyle(c: Context) = sp(c).getInt("ccStyle", 0)
    fun setCcStyle(c: Context, v: Int) = sp(c).edit().putInt("ccStyle", v).apply()
    fun ccMedia(c: Context) = sp(c).getInt("ccMedia", 0)
    fun setCcMedia(c: Context, v: Int) = sp(c).edit().putInt("ccMedia", v).apply()
    fun hideSys(c: Context) = sp(c).getBoolean("hidesys", true)
    fun setHideSys(c: Context, v: Boolean) = sp(c).edit().putBoolean("hidesys", v).apply()
    fun islandMode(c: Context) = sp(c).getInt("imode", 1) // 0 biasa, 1 iOS
    fun setIslandMode(c: Context, v: Int) = sp(c).edit().putInt("imode", v).apply()
    fun buttons(c: Context) = sp(c).getBoolean("btn", true)
    fun setButtons(c: Context, v: Boolean) = sp(c).edit().putBoolean("btn", v).apply()
    fun persistCharge(c: Context) = sp(c).getBoolean("pcharge", false)
    fun setPersistCharge(c: Context, v: Boolean) = sp(c).edit().putBoolean("pcharge", v).apply()
    fun speedOn(c: Context) = sp(c).getBoolean("speedon", false)
    fun setSpeedOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("speedon", v).apply()
    fun torchInd(c: Context) = sp(c).getBoolean("torchind", true)
    fun setTorchInd(c: Context, v: Boolean) = sp(c).edit().putBoolean("torchind", v).apply()
    fun recInd(c: Context) = sp(c).getBoolean("recind", true)
    fun setRecInd(c: Context, v: Boolean) = sp(c).edit().putBoolean("recind", v).apply()
    fun camShape(c: Context) = sp(c).getInt("camshape", 0) // 0 otomatis, 1 punchhole kiri, 2 teardrop
    fun setCamShape(c: Context, v: Int) = sp(c).edit().putInt("camshape", v).apply()
    fun recPkgs(c: Context): Set<String> = sp(c).getStringSet("recpkgs", emptySet()) ?: emptySet()
    fun setRecPkgs(c: Context, v: Set<String>) = sp(c).edit().putStringSet("recpkgs", HashSet(v)).apply()
    fun recQuality(c: Context) = sp(c).getInt("recq", 1) // 0 HD 720p, 1 Full HD 1080p, 2 asli
    fun setRecQuality(c: Context, v: Int) = sp(c).edit().putInt("recq", v).apply()
    fun recMic(c: Context) = sp(c).getBoolean("recmic", false)
    fun setRecMic(c: Context, v: Boolean) = sp(c).edit().putBoolean("recmic", v).apply()
    fun ringerPill(c: Context) = sp(c).getBoolean("ringerpill", true)
    fun setRingerPill(c: Context, v: Boolean) = sp(c).edit().putBoolean("ringerpill", v).apply()
    fun btPill(c: Context) = sp(c).getBoolean("btpill", true)
    fun setBtPill(c: Context, v: Boolean) = sp(c).edit().putBoolean("btpill", v).apply()
    fun hotspotInd(c: Context) = sp(c).getBoolean("hotspotind", true)
    fun setHotspotInd(c: Context, v: Boolean) = sp(c).edit().putBoolean("hotspotind", v).apply()
    fun unlockPill(c: Context) = sp(c).getBoolean("unlockpill", true)
    fun setUnlockPill(c: Context, v: Boolean) = sp(c).edit().putBoolean("unlockpill", v).apply()
    fun volIsland(c: Context) = sp(c).getBoolean("volisland", false)
    fun setVolIsland(c: Context, v: Boolean) = sp(c).edit().putBoolean("volisland", v).apply()
    /** Fisika animasi island. Kunci: pwd/phd = damping lebar/tinggi (x100), pws/phs = stiffness, piv = kecepatan awal, pdl = jeda tinggi (ms). */
    fun phys(c: Context, k: String): Int {
        val v = sp(c).getInt(k, Int.MIN_VALUE)
        if (v != Int.MIN_VALUE) return v
        val ios = islandMode(c) == 1
        return when (k) {
            "pwd" -> if (ios) 70 else 100
            "phd" -> if (ios) 64 else 100
            "pws" -> if (ios) 380 else 800
            "phs" -> if (ios) 300 else 800
            "pop" -> 100
            else -> 0
        }
    }
    fun setPhys(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun torchAuto(c: Context) = sp(c).getBoolean("torchauto", false)
    fun setTorchAuto(c: Context, v: Boolean) = sp(c).edit().putBoolean("torchauto", v).apply()
    fun volThin(c: Context) = sp(c).getBoolean("volthin", true)
    fun setVolThin(c: Context, v: Boolean) = sp(c).edit().putBoolean("volthin", v).apply()
    fun sysPill(c: Context) = sp(c).getBoolean("syspill", true)
    fun setSysPill(c: Context, v: Boolean) = sp(c).edit().putBoolean("syspill", v).apply()
    fun tempInd(c: Context) = sp(c).getBoolean("tempind", false)
    fun setTempInd(c: Context, v: Boolean) = sp(c).edit().putBoolean("tempind", v).apply()
    fun fontIdx(c: Context) = sp(c).getInt("fontidx", 0)
    fun setFont(c: Context, v: Int) = sp(c).edit().putInt("fontidx", v).apply()
    fun fpsOn(c: Context) = sp(c).getBoolean("fpson", false)
    fun setFpsOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("fpson", v).apply()

    // ---- Tampilan aplikasi & island (gaya LiquidIsland) ----
    /** 0 sistem, 1 gelap, 2 OLED, 3 terang */
    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()
    /** 0 biru, 1 ungu, 2 pink, 3 merah */
    fun accent(c: Context) = sp(c).getInt("accent", 0)
    fun setAccent(c: Context, v: Int) = sp(c).edit().putInt("accent", v).apply()
    /** 0 otomatis, selain itu Hz yang diminta (60/90/120/165) */
    fun refreshRate(c: Context) = sp(c).getInt("refresh", 0)
    fun setRefreshRate(c: Context, v: Int) = sp(c).edit().putInt("refresh", v).apply()
    /** 0 lingkaran, 1 squircle, 2 adaptif, 3 kustom */
    fun bubbleShape(c: Context) = sp(c).getInt("bshape", 0)
    fun setBubbleShape(c: Context, v: Int) = sp(c).edit().putInt("bshape", v).apply()
    fun bubbleW(c: Context) = sp(c).getInt("bw", 46)
    fun setBubbleW(c: Context, v: Int) = sp(c).edit().putInt("bw", v).apply()
    fun bubbleR(c: Context) = sp(c).getInt("br", 16)
    fun setBubbleR(c: Context, v: Int) = sp(c).edit().putInt("br", v).apply()
    /** 0 bubble bulat di samping pil, 1 kartu bertumpuk */
    fun mtMode(c: Context) = sp(c).getInt("mtmode", 0)
    fun setMtMode(c: Context, v: Int) = sp(c).edit().putInt("mtmode", v).apply()
    fun refraction(c: Context) = sp(c).getInt("refr", 50)
    fun setRefraction(c: Context, v: Int) = sp(c).edit().putInt("refr", v).apply()
    fun tension(c: Context) = sp(c).getInt("tens", 50)
    fun setTension(c: Context, v: Int) = sp(c).edit().putInt("tens", v).apply()
    fun actMusic(c: Context) = sp(c).getBoolean("actmusic", true)
    fun setActMusic(c: Context, v: Boolean) = sp(c).edit().putBoolean("actmusic", v).apply()
    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()
    /** Tambahan lebar pil saat compact (dp). Default 0 = pil kecil seperti biasa. */
    fun compactExtra(c: Context) = sp(c).getInt("cwx", 0)
    fun setCompactExtra(c: Context, v: Int) = sp(c).edit().putInt("cwx", v).apply()

    /** Ekspor semua pengaturan jadi teks JSON (untuk Config Manager). */
    fun exportJson(c: Context): String {
        val o = org.json.JSONObject()
        for ((k, v) in sp(c).all) {
            when (v) {
                is Int, is Long, is Float, is Boolean, is String -> o.put(k, v)
                is Set<*> -> o.put(k, org.json.JSONArray(v.map { it.toString() }))
            }
        }
        return o.toString()
    }

    /** Impor pengaturan dari teks JSON hasil ekspor. Mengembalikan true kalau berhasil. */
    fun importJson(c: Context, text: String): Boolean {
        return try {
            val o = org.json.JSONObject(text.trim())
            val e = sp(c).edit()
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                when (val v = o.get(k)) {
                    is Boolean -> e.putBoolean(k, v)
                    is Int -> e.putInt(k, v)
                    is String -> e.putString(k, v)
                    is org.json.JSONArray -> {
                        val set = HashSet<String>()
                        for (i in 0 until v.length()) set.add(v.getString(i))
                        e.putStringSet(k, set)
                    }
                }
            }
            e.apply()
            true
        } catch (_: Throwable) { false }
    }
}
