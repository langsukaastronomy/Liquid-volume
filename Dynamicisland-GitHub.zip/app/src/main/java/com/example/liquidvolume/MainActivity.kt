package com.example.liquidvolume

import android.app.Activity
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.transition.TransitionManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation

/**
 * Layar pengaturan bergaya LiquidIsland: tema terang/gelap/OLED, warna aksen,
 * kartu kaca, navigasi bawah 5 tab (Home, Activities, Shortcuts, Settings, Appearance).
 */
class MainActivity : Activity() {
    companion object {
        var tab = 0
        var actKind = 0
        var actExpanded = false
    }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(x: Int) = (x * d).toInt()

    private var dark = false
    private var oled = false
    private var cText = 0
    private var cSub = 0
    private var cAccent = 0
    private var cField = 0
    private var cStroke = 0
    private var cCard = 0
    private val GREEN = Color.parseColor("#30D158")
    private val RED = Color.parseColor("#FF453A")

    private val statusUpdaters = ArrayList<() -> Unit>()
    private var recBtn: Button? = null

    // ---------------------------------------------------------------- tema
    private class Backdrop(val dark: Boolean, val oled: Boolean) : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (oled) { c.drawColor(Color.BLACK); return }
            if (dark) {
                p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF0B0F18.toInt(), 0xFF121A2B.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, p)
                blob(c, w * 0.10f, h * 0.05f, w * 0.90f, 0x332F7BFF)
                blob(c, w * 0.95f, h * 0.80f, w * 0.90f, 0x2A7C3AED)
            } else {
                p.shader = LinearGradient(0f, 0f, 0f, h, 0xFFF4F6FB.toInt(), 0xFFDDE6F6.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, p)
                blob(c, w * 0.05f, h * 0.10f, w * 0.90f, 0x55BCD2FF)
                blob(c, w * 0.95f, h * 0.75f, w * 0.90f, 0x44C9B8FF)
            }
            p.shader = null
        }
        private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
            p.shader = RadialGradient(x, y, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, r, p)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: ColorFilter?) {}
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.OPAQUE
    }

    private fun palette() {
        val t = Prefs.theme(this)
        val sys = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        dark = t == 1 || t == 2 || (t == 0 && sys)
        oled = t == 2
        cAccent = Color.parseColor(arrayOf("#2F7BFF", "#9B51E0", "#FF4D7D", "#FF3B30")[Prefs.accent(this).coerceIn(0, 3)])
        if (dark) {
            cText = Color.WHITE
            cSub = Color.parseColor("#9AA3B5")
            cCard = if (oled) 0x16FFFFFF else 0x20FFFFFF
            cStroke = 0x2EFFFFFF
            cField = 0x14FFFFFF
        } else {
            cText = Color.parseColor("#10131A")
            cSub = Color.parseColor("#6B7385")
            cCard = 0xCCFFFFFF.toInt()
            cStroke = 0x1A8FA0C0
            cField = 0x99FFFFFF.toInt()
        }
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    // ---------------------------------------------------------------- pembangun tampilan kecil
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lpm(w: Int = -1, h: Int = -2, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top; bottomMargin = bottom }

    private fun bgRound(fill: Int, stroke: Int, radius: Int, sw: Int = 1): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius * d
        if (sw > 0) setStroke(maxOf(1, (sw * d).toInt()), stroke)
    }

    private fun cardBox(parent: LinearLayout, top: Int = 12): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgRound(cCard, cStroke, 22)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        parent.addView(c, lpm(top = dp(top)))
        return c
    }

    private fun header(title: String, sub: String?): View {
        val h = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        h.addView(tv(title, 28f, cText, true))
        if (sub != null) h.addView(tv(sub, 11f, cAccent, true).apply { letterSpacing = 0.12f })
        return h
    }

    private fun section(parent: LinearLayout, text: String) {
        parent.addView(tv(text, 11f, cSub, true).apply { letterSpacing = 0.1f }, lpm(top = dp(22), bottom = dp(2)))
    }

    private fun note(parent: LinearLayout, text: String) {
        parent.addView(tv(text, 11.5f, cSub).apply { setPadding(0, dp(4), 0, 0) })
    }

    private fun tintSwitch(s: Switch) {
        val on = intArrayOf(android.R.attr.state_checked)
        val off = intArrayOf(-android.R.attr.state_checked)
        s.thumbTintList = ColorStateList(arrayOf(on, off), intArrayOf(Color.WHITE, Color.parseColor("#F2F2F2")))
        s.trackTintList = ColorStateList(arrayOf(on, off),
            intArrayOf(withAlpha(cAccent, 0xE0), if (dark) 0x44FFFFFF else 0x33000000))
    }

    private fun toggle(parent: LinearLayout, title: String, sub: String?, on: Boolean, enabled: Boolean = true, cb: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 14f, cText, true))
        if (sub != null) col.addView(tv(sub, 11.5f, cSub).apply { setPadding(0, dp(2), dp(10), 0) })
        val sw = Switch(this).apply {
            isChecked = on; isEnabled = enabled
            tintSwitch(this)
            setOnCheckedChangeListener { _, v -> cb(v) }
        }
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(sw)
        parent.addView(row, lpm(top = dp(12)))
    }

    private fun slider(parent: LinearLayout, title: String, cur: Int, lo: Int, hi: Int,
                       fmt: (Int) -> String, onChange: (Int) -> Unit, onDone: () -> Unit = {}) {
        val c = cur.coerceIn(lo, hi)
        val vt = tv(fmt(c), 13f, cAccent, true)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(title, 14f, cText, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(vt)
        val sb = SeekBar(this).apply {
            max = hi - lo
            progress = c - lo
            progressTintList = ColorStateList.valueOf(cAccent)
            progressBackgroundTintList = ColorStateList.valueOf(if (dark) 0x33FFFFFF else 0x22000000)
            thumb = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setSize(dp(26), dp(26))
                setStroke(dp(1), 0x33000000)
            }
            setPadding(dp(14), 0, dp(14), 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    vt.text = fmt(p + lo)
                    if (fromUser) onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { onDone() }
            })
        }
        parent.addView(head, lpm(top = dp(14)))
        parent.addView(sb, lpm(top = dp(2)))
    }

    private fun collapsible(parent: LinearLayout, icon: String, title: String, open: Boolean, build: LinearLayout.() -> Unit) {
        val card = cardBox(parent)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val ic = IconView(this, icon, cAccent, 18f).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = bgRound(withAlpha(cAccent, 0x26), 0, 12, 0)
        }
        head.addView(ic)
        head.addView(tv(title, 15f, cText, true).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        val chev = IconView(this, if (open) "chevup" else "chevdown", cSub, 18f)
        head.addView(chev)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (open) View.VISIBLE else View.GONE
            build()
        }
        head.setOnClickListener {
            TransitionManager.beginDelayedTransition(card)
            val show = body.visibility != View.VISIBLE
            body.visibility = if (show) View.VISIBLE else View.GONE
            chev.set(if (show) "chevup" else "chevdown", cSub)
        }
        card.addView(head)
        card.addView(body)
    }

    private fun button(parent: LinearLayout, text: String, primary: Boolean, click: () -> Unit): Button {
        val b = Button(this).apply {
            this.text = text; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else cText)
            background = if (primary) bgRound(cAccent, 0, 26, 0) else bgRound(cField, cStroke, 26, 1)
            stateListAnimator = null
            setOnClickListener { click() }
        }
        parent.addView(b, lpm(h = dp(50), top = dp(10)))
        return b
    }

    private fun chipBg(sel: Boolean) =
        if (sel) bgRound(withAlpha(cAccent, 0x22), cAccent, 14, 2) else bgRound(cField, cStroke, 14, 1)

    private fun chipRow(parent: LinearLayout, labels: List<String>, sel: Int, faces: Boolean = false, onPick: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cells = ArrayList<TextView>()
        fun style(cur: Int) {
            cells.forEachIndexed { i, t -> t.background = chipBg(i == cur); t.setTextColor(if (i == cur) cAccent else cText) }
        }
        labels.forEachIndexed { i, l ->
            val t = tv(l, 13f, cText, true).apply {
                gravity = Gravity.CENTER
                if (faces) typeface = Fonts.at(i)
                setPadding(dp(6), dp(12), dp(6), dp(12))
                setOnClickListener { style(i); onPick(i) }
            }
            cells.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        style(sel)
        parent.addView(row, lpm(top = dp(10)))
    }

    private fun optionGrid(parent: LinearLayout, titles: List<String>, subs: List<String>, previews: List<View>,
                           sel: Int, onPick: (Int) -> Unit) {
        val cells = ArrayList<LinearLayout>()
        fun style(cur: Int) { cells.forEachIndexed { i, c -> c.background = chipBg(i == cur) } }
        var row: LinearLayout? = null
        titles.forEachIndexed { i, t ->
            if (i % 2 == 0) {
                val nr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                parent.addView(nr, lpm(top = dp(10)))
                row = nr
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
                addView(previews[i], LinearLayout.LayoutParams(-1, dp(52)))
                addView(tv(t, 13f, cText, true).apply { setPadding(0, dp(6), 0, 0); gravity = Gravity.CENTER })
                if (subs[i].isNotEmpty()) addView(tv(subs[i], 10.5f, cSub).apply { gravity = Gravity.CENTER })
                setOnClickListener { style(i); onPick(i) }
            }
            cells.add(cell)
            row!!.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        style(sel)
    }

    // ---------------------------------------------------------------- pratinjau mini
    private fun miniScreen(kind: Int): View {
        val f = FrameLayout(this)
        val g = GradientDrawable()
        g.cornerRadius = 10 * d
        g.setStroke(dp(1), cStroke)
        when (kind) {
            0 -> {
                g.orientation = GradientDrawable.Orientation.LEFT_RIGHT
                g.setColors(intArrayOf(0xFF0B0F18.toInt(), 0xFF0B0F18.toInt(), 0xFFF2F5FB.toInt(), 0xFFF2F5FB.toInt()),
                    floatArrayOf(0f, 0.5f, 0.5f, 1f))
            }
            1 -> g.setColor(0xFF121A2B.toInt())
            2 -> g.setColor(Color.BLACK)
            else -> g.setColor(0xFFF2F5FB.toInt())
        }
        f.background = g
        val pill = View(this).apply { background = bgRound(Color.BLACK, 0x66808080, 8, 1) }
        f.addView(pill, FrameLayout.LayoutParams(dp(56), dp(14), Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(10) })
        return f
    }

    private fun miniBubble(shape: Int): View {
        val f = FrameLayout(this).apply { background = bgRound(Color.parseColor("#9AA9C6"), cStroke, 10, 1) }
        val pill = View(this).apply { background = bgRound(Color.BLACK, 0, 8, 0) }
        f.addView(pill, FrameLayout.LayoutParams(dp(54), dp(16), Gravity.CENTER_VERTICAL or Gravity.START).apply { marginStart = dp(14) })
        val bw = when (shape) { 0 -> 16; 1 -> 16; 2 -> 24; else -> 26 }
        val rad = when (shape) { 0 -> 8; 1 -> 6; 2 -> 8; else -> 5 }
        val b = View(this).apply { background = bgRound(Color.BLACK, 0, rad, 0) }
        f.addView(b, FrameLayout.LayoutParams(dp(bw), dp(16), Gravity.CENTER_VERTICAL or Gravity.START).apply { marginStart = dp(72) })
        return f
    }

    private fun miniCards(): View {
        val f = FrameLayout(this).apply { background = bgRound(Color.parseColor("#9AA9C6"), cStroke, 10, 1) }
        f.addView(View(this).apply { background = bgRound(0xFF2A2A30.toInt(), 0, 8, 0) },
            FrameLayout.LayoutParams(dp(70), dp(18), Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(8) })
        f.addView(View(this).apply { background = bgRound(Color.BLACK, 0, 8, 0) },
            FrameLayout.LayoutParams(dp(82), dp(20), Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(14) })
        return f
    }

    private fun artView(): View = View(this).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#FF3B6B"), Color.parseColor("#7C3AED"), Color.parseColor("#2F7BFF"))
        ).apply { cornerRadius = 7 * d }
    }

    private val actNames = listOf("Musik", "Charging", "Rekam layar", "Senter", "Kecepatan", "FPS", "Suhu", "Hotspot")
    private val actIcons = listOf("music", "bolt", "rec", "torch", "updown", "gauge", "thermo", "link")
    private val actHex = listOf("#FF375F", "#30D158", "#FF3B30", "#FFD60A", "#0A84FF", "#30D158", "#FF9F0A", "#30D158")
    private val actCompact = listOf("", "88%", "00:42", "Senter", "1.2 MB/s", "60 FPS", "34°C", "Hotspot")
    private val actTitle = listOf("Starboy", "Mengisi daya", "Merekam layar", "Senter menyala", "Kecepatan internet", "Frame layar", "Suhu baterai", "Hotspot aktif")
    private val actSub = listOf("The Weeknd", "88% · 12,4 W", "00:42 · HD", "Ketuk untuk mematikan", "↓ 1,2 MB/s   ↑ 0,3 MB/s", "60 FPS stabil", "34°C · normal", "2 perangkat terhubung")
    private val actDesc = listOf(
        "Pil musik dengan sampul lagu dan batang equalizer.",
        "Ikon petir + persen baterai tetap tampil selama HP dicas.",
        "Titik merah berkedip + durasi saat merekam layar (butuh akses notifikasi).",
        "Ikon senter dan tombol Matikan saat senter menyala.",
        "Kecepatan unduh/unggah langsung di pil.",
        "Angka frame layar (FPS) tampil di pil.",
        "Ikon dan suhu baterai (°C) tampil di island.",
        "Ikon hotspot hijau selama hotspot menyala (tergantung HP).")

    private fun actGet(k: Int): Boolean = when (k) {
        0 -> Prefs.actMusic(this)
        1 -> Prefs.persistCharge(this)
        2 -> Prefs.recInd(this)
        3 -> Prefs.torchInd(this)
        4 -> Prefs.speedOn(this)
        5 -> Prefs.fpsOn(this)
        6 -> Prefs.tempInd(this)
        else -> Prefs.hotspotInd(this)
    }

    private fun actSet(k: Int, v: Boolean) {
        when (k) {
            0 -> Prefs.setActMusic(this, v)
            1 -> Prefs.setPersistCharge(this, v)
            2 -> Prefs.setRecInd(this, v)
            3 -> Prefs.setTorchInd(this, v)
            4 -> Prefs.setSpeedOn(this, v)
            5 -> Prefs.setFpsOn(this, v)
            6 -> Prefs.setTempInd(this, v)
            else -> Prefs.setHotspotInd(this, v)
        }
        VolumeService.instance?.island?.refresh()
    }

    private fun pillShell(radiusDp: Int): FrameLayout = FrameLayout(this).apply {
        background = bgRound(Color.BLACK, 0x33808080, radiusDp, 1)
    }

    private fun activityPreview(kind: Int, expanded: Boolean): View {
        val col = Color.parseColor(actHex[kind])
        if (!expanded) {
            val box = pillShell(20)
            box.minimumWidth = dp(220)
            box.minimumHeight = dp(40)
            if (kind == 0) {
                box.addView(artView(), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(10) })
                box.addView(BarsView(this, col, 4, 22, 16), FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(16) })
            } else {
                box.addView(IconView(this, actIcons[kind], col, 18f),
                    FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(14) })
                box.addView(tv(actCompact[kind], 13f, Color.WHITE, true),
                    FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(16) })
            }
            return box
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgRound(Color.BLACK, 0x33808080, 30, 1)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            minimumWidth = dp(280)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (kind == 0) top.addView(artView(), LinearLayout.LayoutParams(dp(46), dp(46)))
        else top.addView(IconView(this, actIcons[kind], col, 22f).apply {
            setPadding(dp(11), dp(11), dp(11), dp(11)); background = bgRound(withAlpha(col, 0x33), 0, 23, 0)
        })
        val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        txt.addView(tv(actTitle[kind], 15f, Color.WHITE, true))
        txt.addView(tv(actSub[kind], 12f, Color.parseColor("#9A9AA5")))
        top.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
        if (kind == 0 || kind == 2) top.addView(BarsView(this, col, 4, 22, 16))
        box.addView(top)
        if (kind == 0) {
            val track = FrameLayout(this).apply { background = bgRound(0x33FFFFFF, 0, 3, 0) }
            track.addView(View(this).apply { background = bgRound(Color.WHITE, 0, 3, 0) }, FrameLayout.LayoutParams(dp(110), -1))
            box.addView(track, lpm(h = dp(4), top = dp(14)))
            val bt = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            bt.addView(tv("1:24", 11f, Color.parseColor("#9A9AA5")), LinearLayout.LayoutParams(0, -2, 1f))
            bt.addView(IconView(this, "pause", Color.WHITE, 26f))
            bt.addView(tv("-2:36", 11f, Color.parseColor("#9A9AA5")).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(bt, lpm(top = dp(8)))
        }
        return box
    }

    // ---------------------------------------------------------------- status izin
    private fun serviceEnabled() =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    private fun policyGranted() =
        getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    private fun listenerGranted() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun locationGranted() =
        checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun batteryOk() =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun btGranted() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission("android.permission.BLUETOOTH_CONNECT") == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun tile(title: String, ok: () -> Boolean, okText: String, noText: String, tap: () -> Unit): LinearLayout {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bgRound(cCard, cStroke, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { tap() }
        }
        t.addView(tv(title, 12.5f, cSub, true))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val dot = View(this)
        val st = tv("", 14f, cText, true).apply { setPadding(dp(8), 0, 0, 0) }
        row.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
        row.addView(st)
        t.addView(row, lpm(top = dp(6)))
        statusUpdaters.add {
            val good = ok()
            dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (good) GREEN else RED) }
            st.text = if (good) okText else noText
        }
        return t
    }

    private fun refreshStatus() {
        statusUpdaters.forEach { it() }
        recBtn?.text = if (RecorderService.running) "Hentikan rekam layar" else "Mulai rekam layar"
    }

    private fun tryDemo() {
        val s = VolumeService.instance
        if (s == null) Toast.makeText(this, "Aktifkan layanan Aksesibilitas dulu", Toast.LENGTH_SHORT).show()
        else s.island?.demo()
    }

    private fun refreshIsland() { VolumeService.instance?.island?.refresh() }
    private fun refreshIslandSoon() { VolumeService.instance?.island?.refreshSoon() }

    // ---------------------------------------------------------------- HOME
    private fun buildHome(col: LinearLayout) {
        col.addView(header("Alat IOS", "LIQUID EDITION"))

        val pc = FrameLayout(this).apply {
            background = bgRound(cCard, cStroke, 24)
            setOnClickListener { tryDemo() }
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(30), dp(16), dp(22))
        }
        val pill = pillShell(17)
        inner.addView(pill, lpm(w = dp(132), h = dp(34)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        inner.addView(tv("Tap to Expand Preview", 11f, cSub, true).apply { letterSpacing = 0.06f; setPadding(0, dp(20), 0, 0) })
        pc.addView(inner, FrameLayout.LayoutParams(-1, -2))
        pc.addView(View(this).apply { background = bgRound(cAccent, 0, 2, 0) },
            FrameLayout.LayoutParams(dp(3), -1, Gravity.START).apply { topMargin = dp(20); bottomMargin = dp(20) })
        col.addView(pc, lpm(top = dp(16)))

        section(col, "CORE FEATURES")
        val tiles = listOf(
            tile("Accessibility", { serviceEnabled() }, "Active", "Stopped") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            tile("Notifications", { listenerGranted() }, "Granted", "Required") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            },
            tile("Do Not Disturb", { policyGranted() }, "Granted", "Required") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            },
            tile("Location (Wi-Fi)", { locationGranted() }, "Granted", "Required") {
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 7)
            },
            tile("Battery Limit", { batteryOk() }, "Unrestricted", "Required") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            tile("Bluetooth", { btGranted() }, "Granted", "Required") {
                if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), 8)
            }
        )
        var row: LinearLayout? = null
        tiles.forEachIndexed { i, t ->
            if (i % 2 == 0) {
                val nr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                col.addView(nr, lpm(top = dp(10)))
                row = nr
            }
            row!!.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        note(col, "• Di beberapa HP, izin ini dibutuhkan agar layanan latar belakang berjalan benar.")

        button(col, "Coba Dynamic Island", true) { tryDemo() }
        button(col, "Tampilkan panel volume", false) {
            if (!serviceEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else {
                val s = VolumeService.instance
                if (s != null) s.showPanel()
                else Toast.makeText(this, "Layanan sedang dimulai, coba lagi sebentar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------- ACTIVITIES
    private fun buildActivities(col: LinearLayout) {
        col.addView(header("Activities", null))

        val pcard = cardBox(col, 14)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GREEN) } },
            LinearLayout.LayoutParams(dp(7), dp(7)))
        top.addView(tv("Live Preview", 11f, cSub, true).apply { setPadding(dp(6), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        val modeLabel = tv("Compact", 11f, cAccent, true)
        top.addView(modeLabel)
        pcard.addView(top)
        val holder = FrameLayout(this)
        pcard.addView(holder, lpm(top = dp(14), bottom = dp(4)))

        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = bgRound(cField, cStroke, 20); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        val sCompact = tv("Compact", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        val sExpanded = tv("Expanded", 13f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        seg.addView(sCompact, LinearLayout.LayoutParams(0, -2, 1f))
        seg.addView(sExpanded, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(seg, lpm(top = dp(12)))

        val chipCells = ArrayList<LinearLayout>()
        val chipIcons = ArrayList<IconView>()
        val chipLabels = ArrayList<TextView>()
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val chipRowV = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        chipScroll.addView(chipRowV)
        col.addView(chipScroll, lpm(top = dp(10)))

        var enableBody: LinearLayout? = null
        fun render() {
            holder.removeAllViews()
            holder.addView(activityPreview(actKind, actExpanded), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            modeLabel.text = if (actExpanded) "Expanded" else "Compact"
            sCompact.background = if (!actExpanded) bgRound(cAccent, 0, 17, 0) else null
            sExpanded.background = if (actExpanded) bgRound(cAccent, 0, 17, 0) else null
            sCompact.setTextColor(if (!actExpanded) Color.WHITE else cText)
            sExpanded.setTextColor(if (actExpanded) Color.WHITE else cText)
            chipCells.forEachIndexed { i, c ->
                val s = i == actKind
                c.background = chipBg(s)
                chipIcons[i].tint(if (s) cAccent else cText)
                chipLabels[i].setTextColor(if (s) cAccent else cText)
            }
            enableBody?.let { b ->
                b.removeAllViews()
                val k = actKind
                toggle(b, "Aktifkan ${actNames[k]}", actDesc[k], actGet(k)) { actSet(k, it) }
            }
        }
        sCompact.setOnClickListener { actExpanded = false; render() }
        sExpanded.setOnClickListener { actExpanded = true; render() }
        actNames.forEachIndexed { i, n ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(10), dp(6), dp(8))
                setOnClickListener { actKind = i; render() }
            }
            val ic = IconView(this, actIcons[i], cText, 22f)
            val lb = tv(n, 10.5f, cText, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
            cell.addView(ic); cell.addView(lb)
            chipCells.add(cell); chipIcons.add(ic); chipLabels.add(lb)
            chipRowV.addView(cell, LinearLayout.LayoutParams(dp(76), -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        }

        collapsible(col, "power", "Enable Activity", true) { enableBody = this }
        collapsible(col, "sliders", "Geometry & Sizes", false) {
            slider(this, "Lebar pil saat compact", Prefs.compactExtra(this@MainActivity), 0, 140, { "$it dp" },
                { Prefs.setCompactExtra(this@MainActivity, it) }, { refreshIsland() })
            slider(this, "Lebar pil", Prefs.adj(this@MainActivity, "dw"), -30, 100, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dw", it); refreshIslandSoon() })
            slider(this, "Tinggi pil", Prefs.adj(this@MainActivity, "dh"), -8, 16, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dh", it); refreshIslandSoon() })
        }
        collapsible(col, "bell", "Activity Features", false) {
            toggle(this, "Status dering di island", "Pil Dering / Getar / Hening saat mode dering berubah.", Prefs.ringerPill(this@MainActivity)) { Prefs.setRingerPill(this@MainActivity, it) }
            toggle(this, "Bluetooth terhubung", "Nama perangkat + \"Terhubung\" saat earbud tersambung.", Prefs.btPill(this@MainActivity)) { Prefs.setBtPill(this@MainActivity, it) }
            toggle(this, "Wi-Fi, Bluetooth, mode pesawat", "Pil On/Off saat salah satunya diubah.", Prefs.sysPill(this@MainActivity)) { Prefs.setSysPill(this@MainActivity, it) }
            toggle(this, "Centang saat HP terbuka", "Centang hijau singkat setiap layar terbuka.", Prefs.unlockPill(this@MainActivity)) { Prefs.setUnlockPill(this@MainActivity, it) }
            toggle(this, "Senter mati otomatis", "Senter dimatikan sendiri setelah 8 menit.", Prefs.torchAuto(this@MainActivity)) { Prefs.setTorchAuto(this@MainActivity, it) }
        }

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b1 = Button(this).apply {
            text = "Reset semua ukuran"; isAllCaps = false; textSize = 13f; setTextColor(cText)
            background = bgRound(cField, cStroke, 26, 1); stateListAnimator = null
            setOnClickListener {
                listOf("dw", "dh", "dx", "dy").forEach { Prefs.setAdj(this@MainActivity, it, 0) }
                Prefs.setCompactExtra(this@MainActivity, 60)
                refreshIslandSoon()
                recreate()
            }
        }
        btns.addView(b1, LinearLayout.LayoutParams(0, dp(50), 1f))
        col.addView(btns, lpm(top = dp(14)))
        render()
    }

    // ---------------------------------------------------------------- SHORTCUTS
    private fun buildShortcuts(col: LinearLayout) {
        col.addView(header("Features & Shortcuts", null))

        val pc = FrameLayout(this).apply { background = bgRound(cCard, cStroke, 24); setOnClickListener { tryDemo() } }
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), dp(26), dp(16), dp(18)) }
        val pill = pillShell(15).apply { minimumWidth = dp(120); minimumHeight = dp(30) }
        pill.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#FFB020")) } },
            FrameLayout.LayoutParams(dp(10), dp(10), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(16) })
        inner.addView(pill, lpm(w = dp(120), h = dp(30)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        inner.addView(tv("TAP ISLAND UNTUK MENCOBA", 10.5f, cSub, true).apply { letterSpacing = 0.1f; setPadding(0, dp(16), 0, 0) })
        pc.addView(inner, FrameLayout.LayoutParams(-1, -2))
        pc.addView(View(this).apply { background = bgRound(Color.parseColor("#FFB020"), 0, 2, 0) },
            FrameLayout.LayoutParams(dp(3), -1, Gravity.START).apply { topMargin = dp(18); bottomMargin = dp(18) })
        col.addView(pc, lpm(top = dp(16)))

        collapsible(col, "pencil", "Gesture Control", true) {
            toggle(this, "Tombol hening & Jangan ganggu", "Ketuk titik tiga (...) di atas pil volume untuk membuka lonceng dan bulan.", Prefs.buttons(this@MainActivity)) { Prefs.setButtons(this@MainActivity, it) }
            toggle(this, "Volume di island", "Tombol volume menampilkan pil iOS di island, bukan panel di tepi.", Prefs.volIsland(this@MainActivity)) { Prefs.setVolIsland(this@MainActivity, it) }
            toggle(this, "Volume menyusut jadi garis tipis", "Kapsul volume mengecil jadi garis tipis setelah sebentar.", Prefs.volThin(this@MainActivity)) { Prefs.setVolThin(this@MainActivity, it) }
            toggle(this, "Haptic feedback", "Getaran halus saat island diketuk.", Prefs.haptic(this@MainActivity)) { Prefs.setHaptic(this@MainActivity, it) }
        }
        collapsible(col, "bellslash", "Notifikasi", false) {
            toggle(this, "Sembunyikan pop-up notifikasi sistem", "Hanya Dynamic Island yang muncul; notifikasi tetap ada di panel notifikasi.", Prefs.hideSys(this@MainActivity)) { Prefs.setHideSys(this@MainActivity, it) }
        }
        collapsible(col, "rec", "Rekam layar HD", false) {
            note(this, "Video MP4 disimpan di Movies/AlatIOS. Saat merekam, titik merah + menitan tampil di island.")
            chipRow(this, listOf("HD 720p", "Full HD", "Asli"), Prefs.recQuality(this@MainActivity)) { Prefs.setRecQuality(this@MainActivity, it) }
            toggle(this, "Rekam suara mikrofon", "Ikut merekam suara dari mikrofon (butuh izin mikrofon).", Prefs.recMic(this@MainActivity)) { Prefs.setRecMic(this@MainActivity, it) }
            recBtn = button(this, "Mulai rekam layar", true) { startActivity(Intent(this@MainActivity, RecordActivity::class.java)) }
            button(this, "Pilih aplikasi perekam layar", false) { pickRecorders() }
        }
    }

    // ---------------------------------------------------------------- SETTINGS
    private fun buildSettings(col: LinearLayout) {
        col.addView(header("Settings", null))

        collapsible(col, "power", "System Presence", true) {
            toggle(this, "Island Enabled", "Butuh layanan Aksesibilitas aktif.", Prefs.islandOn(this@MainActivity)) { Prefs.setIslandOn(this@MainActivity, it); refreshIsland() }
            toggle(this, "Pil selalu tampil di kamera", "Pil hitam menetap, melebar saat ada kejadian.", Prefs.islandIdle(this@MainActivity)) { Prefs.setIslandIdle(this@MainActivity, it); refreshIsland() }
            toggle(this, "Liquid Glass island (eksperimen)", "Island jadi kaca; kilau bergeser saat HP dimiringkan.", Prefs.islandGlass(this@MainActivity)) { Prefs.setIslandGlass(this@MainActivity, it); refreshIsland() }
        }
        collapsible(col, "grid", "Liquid Material", false) {
            slider(this, "Refraction", Prefs.refraction(this@MainActivity), 0, 100, { "$it%" },
                { Prefs.setRefraction(this@MainActivity, it) }, { refreshIsland() })
            slider(this, "Surface Tension", Prefs.tension(this@MainActivity), 0, 100, { "$it%" },
                { Prefs.setTension(this@MainActivity, it) }, { refreshIsland() })
            slider(this, "Opacity", Prefs.phys(this@MainActivity, "pop").coerceIn(30, 100), 30, 100, { "$it%" },
                { Prefs.setPhys(this@MainActivity, "pop", it) }, { refreshIslandSoon() })
            slider(this, "Island Outline", Prefs.phys(this@MainActivity, "pout").coerceIn(0, 40), 0, 40,
                { String.format(java.util.Locale.US, "%.1f dp", it / 10f) },
                { Prefs.setPhys(this@MainActivity, "pout", it) }, { refreshIslandSoon() })
            toggle(this, "Blur latar asli (panel volume)", "Android 11+. Di Android 10 otomatis pakai kaca berasap buatan.", Prefs.blur(this@MainActivity), Build.VERSION.SDK_INT >= 30) { Prefs.setBlur(this@MainActivity, it) }
        }
        collapsible(col, "sliders", "Geometry", false) {
            slider(this, "Vertical Offset", Prefs.adj(this@MainActivity, "dy"), -20, 80, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dy", it); refreshIslandSoon() })
            slider(this, "Horizontal Offset", Prefs.adj(this@MainActivity, "dx"), -160, 160, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dx", it); refreshIslandSoon() })
            slider(this, "Width", Prefs.adj(this@MainActivity, "dw"), -30, 100, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dw", it); refreshIslandSoon() })
            slider(this, "Height", Prefs.adj(this@MainActivity, "dh"), -8, 16, { "$it dp" },
                { Prefs.setAdj(this@MainActivity, "dh", it); refreshIslandSoon() })
            note(this, "Bentuk kamera depan")
            chipRow(this, listOf("Otomatis", "Punchhole", "Teardrop"), Prefs.camShape(this@MainActivity)) {
                Prefs.setCamShape(this@MainActivity, it); refreshIsland()
            }
            button(this, "Reset ukuran & posisi", false) {
                listOf("dw", "dh", "dx", "dy").forEach { Prefs.setAdj(this@MainActivity, it, 0) }
                refreshIslandSoon(); recreate()
            }
        }
        collapsible(col, "bolt", "Interaction", false) {
            toggle(this, "Haptic feedback", "Getaran halus saat island diketuk.", Prefs.haptic(this@MainActivity)) { Prefs.setHaptic(this@MainActivity, it) }
        }

        section(col, "SUB-SYSTEM CONFIGURATIONS")
        collapsible(col, "play", "Animation Settings", false) {
            note(this, "Atur gerak pil island: membal, kaku, atau lambat. Berlaku langsung.")
            val presets = listOf(
                "iOS" to intArrayOf(70, 64, 380, 300, 0, 0),
                "Default" to intArrayOf(100, 100, 800, 800, 0, 0),
                "Bouncy" to intArrayOf(45, 40, 420, 340, 800, 0),
                "Slow" to intArrayOf(85, 80, 150, 120, 0, 60))
            val prow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            presets.forEach { (name, v) ->
                prow.addView(Button(this@MainActivity).apply {
                    text = name; isAllCaps = false; textSize = 12f; setTextColor(cText)
                    background = bgRound(cField, cStroke, 20, 1); stateListAnimator = null
                    setOnClickListener {
                        listOf("pwd", "phd", "pws", "phs", "piv", "pdl").forEachIndexed { i, k -> Prefs.setPhys(this@MainActivity, k, v[i]) }
                        refreshIslandSoon(); recreate()
                    }
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
            }
            addView(prow, lpm(top = dp(12)))
            val ratio: (Int) -> String = { String.format(java.util.Locale.US, "%.2f", it / 100f) }
            fun ps(title: String, key: String, lo: Int, hi: Int, fmt: (Int) -> String) =
                slider(this, title, Prefs.phys(this@MainActivity, key).coerceIn(lo, hi), lo, hi, fmt,
                    { Prefs.setPhys(this@MainActivity, key, it) }, { refreshIslandSoon() })
            ps("Width Damping", "pwd", 20, 120, ratio)
            ps("Height Damping", "phd", 20, 120, ratio)
            ps("Width Stiffness", "pws", 80, 1200) { it.toString() }
            ps("Height Stiffness", "phs", 80, 1200) { it.toString() }
            ps("Initial Velocity", "piv", 0, 3000) { it.toString() }
            ps("Height Delay", "pdl", 0, 300) { "$it ms" }
        }
        collapsible(col, "link", "Config Manager", false) {
            note(this, "Simpan semua pengaturan ke papan klip, atau tempel dari papan klip untuk memulihkannya.")
            button(this, "Ekspor ke papan klip", false) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Alat IOS config", Prefs.exportJson(this@MainActivity)))
                Toast.makeText(this@MainActivity, "Pengaturan disalin", Toast.LENGTH_SHORT).show()
            }
            button(this, "Impor dari papan klip", false) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val txt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString() ?: ""
                if (Prefs.importJson(this@MainActivity, txt)) {
                    Toast.makeText(this@MainActivity, "Pengaturan dipulihkan", Toast.LENGTH_SHORT).show()
                    refreshIsland(); recreate()
                } else Toast.makeText(this@MainActivity, "Isi papan klip bukan konfigurasi yang valid", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------- APPEARANCE
    private fun buildAppearance(col: LinearLayout) {
        col.addView(header("Appearance", null))

        collapsible(col, "globe", "Theme", true) {
            optionGrid(this, listOf("System", "Dark", "OLED", "Light"), listOf("", "", "", ""),
                listOf(miniScreen(0), miniScreen(1), miniScreen(2), miniScreen(3)), Prefs.theme(this@MainActivity)) {
                Prefs.setTheme(this@MainActivity, it); recreate()
            }
        }
        collapsible(col, "check", "Accent Color", true) {
            val names = listOf("Blue", "Purple", "Pink", "Red")
            val hex = listOf("#2F7BFF", "#9B51E0", "#FF4D7D", "#FF3B30")
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val cells = ArrayList<LinearLayout>()
            fun style(cur: Int) { cells.forEachIndexed { i, c -> c.background = chipBg(i == cur) } }
            names.forEachIndexed { i, n ->
                val cell = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(4), dp(10), dp(4), dp(8))
                    setOnClickListener { Prefs.setAccent(this@MainActivity, i); recreate() }
                }
                cell.addView(View(this@MainActivity).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(hex[i])) }
                }, LinearLayout.LayoutParams(dp(30), dp(30)))
                cell.addView(tv(n, 11f, cText, true).apply { setPadding(0, dp(6), 0, 0) })
                cells.add(cell)
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
            }
            style(Prefs.accent(this@MainActivity))
            addView(row, lpm(top = dp(12)))
        }
        collapsible(col, "gauge", "Island Refresh Rate", false) {
            note(this, "Frame rate yang diminta untuk jendela island. HP memilih nilai terdekat yang didukung layarnya.")
            val rates = listOf(0, 60, 90, 120, 165)
            val cur = rates.indexOf(Prefs.refreshRate(this@MainActivity)).coerceAtLeast(0)
            chipRow(this, listOf("Auto", "60", "90", "120", "165"), cur) {
                Prefs.setRefreshRate(this@MainActivity, rates[it]); refreshIsland()
            }
        }
        collapsible(col, "grid", "Multitasking", false) {
            note(this, "Bagaimana dua aktivitas tampil bersamaan.")
            optionGrid(this, listOf("Circle", "Cards"), listOf("Bubble di samping pil", "Kartu 3D bertumpuk"),
                listOf(miniBubble(0), miniCards()), Prefs.mtMode(this@MainActivity)) {
                Prefs.setMtMode(this@MainActivity, it); refreshIsland()
            }
            note(this, "Multitasking Bubble Shape")
            optionGrid(this, listOf("Circle", "Squircle", "Adaptive", "Custom"),
                listOf("Standar", "Membulat", "Lingkaran/Squircle", "Manual"),
                listOf(miniBubble(0), miniBubble(1), miniBubble(2), miniBubble(3)), Prefs.bubbleShape(this@MainActivity)) {
                Prefs.setBubbleShape(this@MainActivity, it); refreshIsland()
            }
            slider(this, "Bubble Width", Prefs.bubbleW(this@MainActivity), 24, 80, { "$it dp" },
                { Prefs.setBubbleW(this@MainActivity, it) }, { refreshIsland() })
            slider(this, "Corner Radius", Prefs.bubbleR(this@MainActivity), 4, 40, { "$it dp" },
                { Prefs.setBubbleR(this@MainActivity, it) }, { refreshIsland() })
            note(this, "Lebar dan radius dipakai oleh bentuk Adaptive dan Custom.")
        }
        collapsible(col, "sliders", "Island Style", false) {
            note(this, "Mode island")
            chipRow(this, listOf("Mode biasa", "Mode iOS"), Prefs.islandMode(this@MainActivity)) {
                Prefs.setIslandMode(this@MainActivity, it); refreshIsland()
            }
            note(this, "Gaya panel volume")
            chipRow(this, listOf("Blurify", "Liquid glass"), Prefs.style(this@MainActivity)) {
                Prefs.setStyle(this@MainActivity, it)
            }
        }
        collapsible(col, "pencil", "Font island", false) {
            note(this, "Ganti jenis huruf teks di island.")
            val cur = Prefs.fontIdx(this@MainActivity)
            Fonts.names.indices.toList().chunked(4).forEach { grp ->
                val labels = grp.map { Fonts.names[it] }
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                val cells = ArrayList<TextView>()
                grp.forEachIndexed { gi, i ->
                    val t = tv(labels[gi], 13f, if (i == cur) cAccent else cText, true).apply {
                        gravity = Gravity.CENTER
                        typeface = Fonts.at(i)
                        background = chipBg(i == cur)
                        setPadding(dp(4), dp(12), dp(4), dp(12))
                        setOnClickListener { Prefs.setFont(this@MainActivity, i); refreshIsland(); recreate() }
                    }
                    cells.add(t)
                    row.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
                }
                addView(row, lpm(top = dp(10)))
            }
        }
    }

    // ---------------------------------------------------------------- navigasi bawah
    private fun buildNav(root: FrameLayout, scroll: ScrollView, cols: List<LinearLayout>) {
        val navW = resources.displayMetrics.widthPixels - dp(28)
        val tabW = navW / 5
        val navFill = if (oled) 0xEE0A0A0C.toInt() else if (dark) 0xEE1A2030.toInt() else 0xEEF8FAFF.toInt()
        val nav = FrameLayout(this).apply { background = bgRound(navFill, cStroke, 34, 1) }
        val lens = View(this).apply { background = bgRound(withAlpha(cAccent, 0x2A), withAlpha(cAccent, 0x66), 28, 1) }
        nav.addView(lens, FrameLayout.LayoutParams(tabW - dp(6), dp(52), Gravity.TOP or Gravity.START)
            .apply { topMargin = dp(6); marginStart = dp(3) })
        val names = listOf("Home", "Activities", "Shortcuts", "Settings", "Appearance")
        val glyphs = listOf("home", "grid", "pencil", "gear", "globe")
        val navIcons = ArrayList<IconView>()
        val labels = ArrayList<TextView>()
        val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun lensTo(i: Int) {
            SpringAnimation(lens, DynamicAnimation.TRANSLATION_X, (i * tabW).toFloat()).apply {
                spring.stiffness = 420f; spring.dampingRatio = 0.68f
            }.start()
        }
        fun select(i: Int, animate: Boolean) {
            tab = i
            cols.forEachIndexed { k, c -> c.visibility = if (k == i) View.VISIBLE else View.GONE }
            labels.forEachIndexed { k, t -> t.setTextColor(if (k == i) cAccent else cSub) }
            navIcons.forEachIndexed { k, ic -> ic.tint(if (k == i) cAccent else cSub) }
            if (animate) { lensTo(i); scroll.scrollTo(0, 0) } else lens.translationX = (i * tabW).toFloat()
            refreshStatus()
        }
        for (i in 0 until 5) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> lens.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                        MotionEvent.ACTION_UP -> {
                            lens.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                            select(i, true)
                        }
                        MotionEvent.ACTION_CANCEL -> lens.animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                    }
                    true
                }
            }
            val ic = IconView(this, glyphs[i], cSub, 22f).apply { setPadding(0, 0, 0, dp(2)) }
            navIcons.add(ic)
            cell.addView(ic)
            val lb = tv(names[i], 10f, cSub, true).apply { gravity = Gravity.CENTER; maxLines = 1 }
            labels.add(lb)
            cell.addView(lb)
            navRow.addView(cell, LinearLayout.LayoutParams(tabW, dp(64)))
        }
        nav.addView(navRow, FrameLayout.LayoutParams(navW, dp(64)))
        root.addView(nav, FrameLayout.LayoutParams(navW, dp(64), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(14) })
        select(tab.coerceIn(0, 4), false)
    }

    // ---------------------------------------------------------------- siklus hidup
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        palette()
        val barColor = if (oled) Color.BLACK else if (dark) 0xFF0B0F18.toInt() else 0xFFF4F6FB.toInt()
        window.statusBarColor = barColor
        window.navigationBarColor = if (oled) Color.BLACK else if (dark) 0xFF121A2B.toInt() else 0xFFDDE6F6.toInt()
        if (!dark) {
            var f = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = f
        }

        val root = FrameLayout(this).apply { background = Backdrop(dark, oled) }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(page)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        statusUpdaters.clear()
        val cols = ArrayList<LinearLayout>()
        for (i in 0 until 5) {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(24), dp(18), dp(120))
            }
            cols.add(c)
            page.addView(c)
        }
        buildHome(cols[0])
        buildActivities(cols[1])
        buildShortcuts(cols[2])
        buildSettings(cols[3])
        buildAppearance(cols[4])
        buildNav(root, scroll, cols)
        setContentView(root)
        refreshStatus()

        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            need.add("android.permission.POST_NOTIFICATIONS")
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != android.content.pm.PackageManager.PERMISSION_GRANTED)
            need.add("android.permission.BLUETOOTH_CONNECT")
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 8)
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun pickRecorders() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val sel = HashSet(Prefs.recPkgs(this))
        val checked = BooleanArray(apps.size) { sel.contains(apps[it].first) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Aplikasi perekam layar")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on ->
                if (on) sel.add(apps[i].first) else sel.remove(apps[i].first)
            }
            .setPositiveButton("Simpan") { _, _ ->
                Prefs.setRecPkgs(this, sel)
                refreshIsland()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
