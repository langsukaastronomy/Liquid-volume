package com.example.liquidvolume

import android.content.Context
import android.graphics.Typeface

/** Pilihan font untuk teks di island (fitur "Custom fonts"). Memakai font bawaan sistem. */
object Fonts {
    val names = listOf("Default", "Condensed", "Serif", "Mono", "Casual", "Cursive", "Light")
    private val families = listOf(
        "sans-serif", "sans-serif-condensed", "serif", "monospace", "casual", "cursive", "sans-serif-light"
    )

    fun at(i: Int): Typeface = Typeface.create(families[i.coerceIn(0, families.size - 1)], Typeface.NORMAL)
    fun base(c: Context): Typeface = at(Prefs.fontIdx(c))
}
