package com.example.liquidvolume

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Panel: pil slider volume + tombol lonceng (hening) + tombol bulan (Jangan Ganggu).
 * Tiap bagian = kaca: backdrop blur (jika ada) + lensa pembesar + tint + kilau + rim.
 * Semua gerakan pakai spring supaya halus.
 */
class GlassPanelView(ctx: Context, u: Float = 1f, private val showButtons: Boolean = true) : View(ctx) {
    var style = Prefs.LIQUID
        set(v) { field = v; invalidate() }
    var backdrop: Bitmap? = null
    var bdW = 1
    var bdH = 1
    var shown = 0.5f
    var ringer = AudioManager.RINGER_MODE_NORMAL
        set(v) { field = v; invalidate() }
    var dnd = false
        set(v) { field = v; invalidate() }
    var onSlide: ((Float) -> Unit)? = null
    var onBell: (() -> Unit)? = null
    var onMoon: (() -> Unit)? = null
    var onActivity: (() -> Unit)? = null

    private var sliderPress = 0f
    private var bellPress = 0f
    private var moonPress = 0f

    private val d = resources.displayMetrics.density * u
    private val sw = 50 * d
    private val sh = 146 * d
    private val bs = 40 * d
    private val gap = 8 * d
    private val pad = 8 * d

    /** Tombol lonceng & bulan muncul di atas pil saat titik tiga ("...") ditekan. */
    var expanded = false
        private set
    private var expand = 0f
    private val expAnim by lazy {
        anim(prop("ex", { it.expand }, { o, v -> o.expand = v }), 420f, 0.72f)
    }
    /** Tinggi ruang ekstra di atas pil (px); dipakai layanan untuk menengahkan pil di layar. */
    val extraPx: Int get() = if (showButtons) (2 * (bs + gap)).toInt() else 0
    private var dotsPress = 0f
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)

    private val sliderR = RectF()
    private val bellR = RectF()
    private val moonR = RectF()

    private fun prop(name: String, g: (GlassPanelView) -> Float, s: (GlassPanelView, Float) -> Unit) =
        object : FloatPropertyCompat<GlassPanelView>(name) {
            override fun getValue(o: GlassPanelView) = g(o)
            override fun setValue(o: GlassPanelView, v: Float) { s(o, v); o.invalidate() }
        }

    private fun anim(p: FloatPropertyCompat<GlassPanelView>, stiff: Float, damp: Float) =
        SpringAnimation(this, p).setSpring(SpringForce().setStiffness(stiff).setDampingRatio(damp))
            .also { it.setMinimumVisibleChange(DynamicAnimation.MIN_VISIBLE_CHANGE_SCALE) }

    private val progAnim = anim(prop("prog", { it.shown }, { o, v -> o.shown = v }), 320f, 0.78f)
    private val sliderAnim = anim(prop("sp", { it.sliderPress }, { o, v -> o.sliderPress = v }), 380f, 0.6f)
    private val bellAnim = anim(prop("bp", { it.bellPress }, { o, v -> o.bellPress = v }), 500f, 0.55f)
    private val moonAnim = anim(prop("mp", { it.moonPress }, { o, v -> o.moonPress = v }), 500f, 0.55f)

    /** Mode garis tipis (ala iOS): kapsul lebar mengecil jadi garis tipis di tepi kanan saat tidak disentuh. */
    var thinEnabled = false
    private var thin = 0f
    private val thinAnim = anim(prop("thin", { it.thin }, { o, v -> o.thin = v }), 240f, 0.82f)
    val isThin: Boolean get() = thin > 0.5f
    val isTouching: Boolean get() = down != 0
    fun setThin(on: Boolean) {
        if (!thinEnabled) return
        thinAnim.animateToFinalPosition(if (on) 1f else 0f)
    }

    private val loc = IntArray(2)
    private val mtx = Matrix()
    private val path = Path()
    private val tmp = Path()
    private val tmp2 = Path()
    private val ar = RectF()
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bdP = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply {
            setSaturation(1.7f)
            postConcat(ColorMatrix(floatArrayOf(
                1.08f, 0f, 0f, 0f, 6f,
                0f, 1.08f, 0f, 0f, 6f,
                0f, 0f, 1.08f, 0f, 6f,
                0f, 0f, 0f, 1f, 0f)))
        })
    }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE; strokeWidth = 0.05f; strokeJoin = Paint.Join.ROUND
    }
    private val iconStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    private val tintL1 = Color.parseColor("#10101826")
    private val tintL2 = Color.parseColor("#0A101826")
    private val tintB1 = Color.parseColor("#50FFFFFF")
    private val tintB2 = Color.parseColor("#38FFFFFF")
    private val fillL1 = Color.parseColor("#F8FFFFFF")
    private val fillL2 = Color.parseColor("#EEFFFFFF")
    private val fillB1 = Color.parseColor("#F5FFFFFF")
    private val fillB2 = Color.parseColor("#D6FFFFFF")
    private val iconLight = Color.parseColor("#F5FFFFFF")
    private val iconDark = Color.parseColor("#CC1B2430")
    private val argb = ArgbEvaluator()
    private val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13f * d; typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(3f * d, 0f, 1f * d, Color.argb(120, 0, 0, 0))
    }

    fun snap(p: Float) { progAnim.cancel(); shown = p.coerceIn(0f, 1f); invalidate() }
    fun setLevel(p: Float) { if (down != 1) progAnim.animateToFinalPosition(p.coerceIn(0f, 1f)) }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((sw + 2 * pad).toInt(), (sh + extraPx + 2 * pad).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = w.toFloat(); pivotY = h - pad - sh / 2f
    }

    // Pil di dasar kotak; lonceng & bulan bertumpuk di atasnya.
    private fun layoutRects() {
        val bottom = height - pad
        val tw = sw - (sw - 7f * d) * thin.coerceIn(0f, 1f)
        sliderR.set(pad + sw - tw, bottom - sh, pad + sw, bottom)
        val bx = pad + (sw - bs) / 2f
        moonR.set(bx, sliderR.top - gap - bs, bx + bs, sliderR.top - gap)
        bellR.set(bx, moonR.top - gap - bs, bx + bs, moonR.top - gap)
    }

    fun toggleExpanded() {
        if (!showButtons) return
        expanded = !expanded
        expAnim.animateToFinalPosition(if (expanded) 1f else 0f)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        layoutRects()
        val cover = ((shown * sh - sw * 0.25f) / (sw * 0.5f)).coerceIn(0f, 1f)
        val iconCol = argb.evaluate(cover, iconLight, iconDark) as Int
        val dotCol = if (shown > 0.84f) iconDark else iconLight
        val mute = (1f - shown / 0.06f).coerceIn(0f, 1f)
        glass(c, sliderR, 1f + 0.07f * sliderPress - 0.06f * mute, 0f, true) { cv ->
            if (thin < 0.4f) speaker(cv, sliderR.centerX(), sliderR.bottom - sw * 0.5f, sw * 0.5f, iconCol, shown)
            if (showButtons && thin < 0.4f) {
                dotP.color = dotCol
                val dy = sliderR.top + 15f * d
                val dr = 2.2f * d * (1f + 0.25f * dotsPress)
                cv.drawCircle(sliderR.centerX() - 7f * d, dy, dr, dotP)
                cv.drawCircle(sliderR.centerX(), dy, dr, dotP)
                cv.drawCircle(sliderR.centerX() + 7f * d, dy, dr, dotP)
            }
        }
        if (showButtons && expand < 0.99f && thin < 0.05f) {
            labelP.alpha = (255 * (1f - expand.coerceIn(0f, 1f)) * (1f - 0.5f * mute)).toInt()
            c.drawText("Volume", sliderR.left + 2f * d, sliderR.top - 10f * d, labelP)
        }
        if (showButtons && expand > 0.01f) {
            val silent = ringer == AudioManager.RINGER_MODE_SILENT
            val ex = expand.coerceIn(0f, 1.2f)
            val al = (255 * ex.coerceIn(0f, 1f)).toInt()
            val ox = sliderR.centerX()
            val oy = sliderR.top
            c.saveLayerAlpha(bellR.left - 12 * d, bellR.top - 12 * d, bellR.right + 12 * d, moonR.bottom + 12 * d, al)
            c.save(); c.scale(ex, ex, ox, oy)
            glass(c, moonR, 1f - 0.1f * moonPress, if (dnd) 1f else 0f, false) { cv ->
                moon(cv, moonR.centerX(), moonR.centerY(), bs * 0.56f, iconLight)
            }
            glass(c, bellR, 1f - 0.1f * bellPress, if (silent) 1f else 0f, false) { cv ->
                bell(cv, bellR.centerX(), bellR.centerY(), bs * 0.56f, iconLight, silent,
                    ringer == AudioManager.RINGER_MODE_VIBRATE)
            }
            c.restore()
            c.restore()
        }
    }

    private fun glass(c: Canvas, r: RectF, sc: Float, active: Float, slider: Boolean, content: (Canvas) -> Unit) {
        val liquid = style == Prefs.LIQUID
        val rad = r.width() / 2f
        val w = r.width()
        c.save()
        c.scale(sc, sc, r.centerX(), r.centerY())
        path.reset()
        path.addRoundRect(r, rad, rad, Path.Direction.CW)
        for (i in 3 downTo 1) {
            fillP.shader = null
            fillP.color = Color.argb(10 + (3 - i) * 6, 0, 0, 0)
            val e = i * 1.6f * d
            ar.set(r.left - e, r.top - e + 2.5f * d, r.right + e, r.bottom + e + 2.5f * d)
            c.drawRoundRect(ar, rad + e, rad + e, fillP)
        }
        c.save()
        c.clipPath(path)

        // 1) latar blur + lensa pembesar (kalau ada hasil screenshot)
        val bd = backdrop
        if (bd != null) {
            getLocationOnScreen(loc)
            val mag = if (liquid) 1.32f else 1f
            val cx = loc[0] + r.centerX()
            val cy = loc[1] + r.centerY()
            val sx = bd.width.toFloat() / bdW
            val sy = bd.height.toFloat() / bdH
            mtx.setScale(mag / sx, mag / sy)
            mtx.postTranslate(cx * (1 - mag) - loc[0], cy * (1 - mag) - loc[1])
            c.drawBitmap(bd, mtx, bdP)
        }

        // 1b) tanpa screenshot (Android 10 / gagal ambil layar): kaca berasap buatan supaya tetap terlihat kaca
        if (bd == null) {
            fillP.shader = LinearGradient(0f, r.top, 0f, r.bottom,
                if (liquid) Color.parseColor("#80514AA8") else Color.parseColor("#8A2E2A70"),
                if (liquid) Color.parseColor("#6636308C") else Color.parseColor("#7A1E1B58"),
                Shader.TileMode.CLAMP)
            c.drawRect(r, fillP)
            fillP.shader = null
        }

        // 2) tint kaca
        fillP.shader = LinearGradient(0f, r.top, 0f, r.bottom,
            if (liquid) tintL1 else tintB1, if (liquid) tintL2 else tintB2, Shader.TileMode.CLAMP)
        c.drawRect(r, fillP)
        if (active > 0f) {
            fillP.shader = null
            fillP.color = Color.argb((70 * active).toInt(), 255, 255, 255)
            c.drawRect(r, fillP)
        }

        // 3) isi level volume
        if (slider) {
            val top = r.bottom - r.height() * shown
            fillP.shader = LinearGradient(0f, top, 0f, r.bottom,
                if (liquid) fillL1 else fillB1, if (liquid) fillL2 else fillB2, Shader.TileMode.CLAMP)
            c.drawRect(r.left, top, r.right, r.bottom, fillP)
            fillP.shader = null
            if (shown > 0.02f && shown < 0.99f) {
                fillP.color = Color.argb(160, 255, 255, 255)
                c.drawRect(r.left, top, r.right, top + 1.6f * d, fillP)
            }
        }

        // 4) kilau specular
        fillP.shader = RadialGradient(r.left + w * 0.32f, r.top + w * 0.35f, w * 1.0f,
            intArrayOf(Color.argb(if (liquid) 120 else 60, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP)
        c.drawRect(r, fillP)
        if (liquid) {
            fillP.shader = RadialGradient(r.right - w * 0.25f, r.bottom - w * 0.2f, w * 0.9f,
                intArrayOf(Color.argb(60, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                null, Shader.TileMode.CLAMP)
            c.drawRect(r, fillP)
        }
        fillP.shader = LinearGradient(r.left, r.top, r.right, r.bottom,
            intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(if (liquid) 60 else 28, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0.15f, 0.3f, 0.5f), Shader.TileMode.CLAMP)
        c.drawRect(r, fillP)
        fillP.shader = null
        rimP.shader = null
        val glowW = floatArrayOf(9f, 5f, 2f)
        val glowA = intArrayOf(14, 24, 40)
        for (k in 0..2) {
            rimP.strokeWidth = glowW[k] * d
            rimP.color = Color.argb(glowA[k], 255, 255, 255)
            c.drawRoundRect(r, rad, rad, rimP)
        }
        c.restore()

        // 5) rim terang di tepi
        if (liquid) {
            rimP.shader = null
            rimP.strokeWidth = 1.2f * d
            rimP.color = Color.argb(120, 255, 214, 170)
            c.save(); c.translate(0.6f * d, 0.8f * d); c.drawRoundRect(r, rad, rad, rimP); c.restore()
        }
        rimP.strokeWidth = 1.4f * d
        rimP.shader = LinearGradient(r.left, r.top, r.right, r.bottom,
            intArrayOf(Color.argb(235, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(150, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, rimP)

        content(c)
        c.restore()
    }

    // ---------- ikon ----------
    private fun speaker(c: Canvas, cx: Float, cy: Float, s: Float, col: Int, level: Float) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        iconFill.color = col
        tmp.reset()
        tmp.moveTo(-.38f, -.16f); tmp.lineTo(-.18f, -.16f); tmp.lineTo(.08f, -.40f)
        tmp.lineTo(.08f, .40f); tmp.lineTo(-.18f, .16f); tmp.lineTo(-.38f, .16f); tmp.close()
        c.drawPath(tmp, iconFill)
        iconStroke.color = col; iconStroke.strokeWidth = .09f
        if (level <= 0.02f) {
            c.drawLine(.16f, -.17f, .42f, .17f, iconStroke)
            c.drawLine(.16f, .17f, .42f, -.17f, iconStroke)
        }
        if (level > 0.04f) { ar.set(-.12f, -.20f, .28f, .20f); c.drawArc(ar, -45f, 90f, false, iconStroke) }
        if (level > 0.5f) { ar.set(-.30f, -.38f, .46f, .38f); c.drawArc(ar, -45f, 90f, false, iconStroke) }
        c.restore()
    }

    private fun bell(c: Canvas, cx: Float, cy: Float, s: Float, col: Int, slash: Boolean, vib: Boolean) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        iconFill.color = col
        tmp.reset()
        ar.set(-.22f, -.34f, .22f, .10f)
        tmp.addArc(ar, 180f, 180f)
        tmp.lineTo(.30f, .20f); tmp.lineTo(-.30f, .20f); tmp.close()
        c.drawPath(tmp, iconFill)
        c.drawCircle(0f, .30f, .07f, iconFill)
        c.drawCircle(0f, -.37f, .04f, iconFill)
        iconStroke.color = col; iconStroke.strokeWidth = .08f
        if (slash) c.drawLine(-.40f, -.38f, .40f, .42f, iconStroke)
        if (vib) {
            c.drawLine(.46f, -.12f, .46f, .12f, iconStroke)
            c.drawLine(-.46f, -.12f, -.46f, .12f, iconStroke)
        }
        c.restore()
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, s: Float, col: Int) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        iconFill.color = col
        tmp.reset(); tmp.addCircle(0f, 0f, .34f, Path.Direction.CW)
        tmp2.reset(); tmp2.addCircle(.17f, -.12f, .30f, Path.Direction.CW)
        tmp.op(tmp2, Path.Op.DIFFERENCE)
        c.drawPath(tmp, iconFill)
        c.restore()
    }

    // ---------- sentuhan ----------
    private var down = 0 // 0 tidak ada, 1 slider, 2 lonceng, 3 bulan, 4 titik tiga

    private fun hit(r: RectF, x: Float, y: Float): Boolean {
        val m = (if (thin > 0.5f) 18 else 4) * d
        return x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m
    }

    private fun slideTo(y: Float) {
        shown = (1f - (y - sliderR.top) / sliderR.height()).coerceIn(0f, 1f)
        invalidate()
        onSlide?.invoke(shown)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        onActivity?.invoke()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (thin > 0f) { thinAnim.cancel(); thin = 0f }
                layoutRects()
                val open = expand > 0.5f
                down = when {
                    showButtons && hit(sliderR, e.x, e.y) && e.y <= sliderR.top + 30 * d -> 4
                    hit(sliderR, e.x, e.y) -> 1
                    showButtons && open && hit(bellR, e.x, e.y) -> 2
                    showButtons && open && hit(moonR, e.x, e.y) -> 3
                    else -> 0
                }
                when (down) {
                    1 -> { progAnim.cancel(); sliderAnim.animateToFinalPosition(1f); slideTo(e.y) }
                    2 -> bellAnim.animateToFinalPosition(1f)
                    3 -> moonAnim.animateToFinalPosition(1f)
                    4 -> { dotsPress = 1f; invalidate() }
                }
                return down != 0
            }
            MotionEvent.ACTION_MOVE -> if (down == 1) slideTo(e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val up = e.actionMasked == MotionEvent.ACTION_UP
                when (down) {
                    1 -> sliderAnim.animateToFinalPosition(0f)
                    2 -> { bellAnim.animateToFinalPosition(0f); if (up && hit(bellR, e.x, e.y)) onBell?.invoke() }
                    3 -> { moonAnim.animateToFinalPosition(0f); if (up && hit(moonR, e.x, e.y)) onMoon?.invoke() }
                    4 -> { dotsPress = 0f; invalidate(); if (up) toggleExpanded() }
                }
                down = 0
            }
        }
        return true
    }
}
