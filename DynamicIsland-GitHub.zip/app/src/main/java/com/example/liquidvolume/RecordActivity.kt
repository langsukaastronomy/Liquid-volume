package com.example.liquidvolume

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/** Meminta izin perekaman layar lalu menjalankan RecorderService (atau menghentikannya kalau sedang merekam). */
class RecordActivity : Activity() {
    private var mic = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACT_STOP))
            finish()
            return
        }
        if (Prefs.recMic(this) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)
        } else {
            mic = Prefs.recMic(this)
            ask()
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        mic = r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED
        ask()
    }

    private fun ask() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, RecorderService::class.java)
                .putExtra("code", res).putExtra("data", data).putExtra("mic", mic))
            // ke layar utama supaya yang terekam bukan halaman aplikasi ini
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
    }
}
