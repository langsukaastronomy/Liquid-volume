package com.example.liquidvolume

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Dibangunkan oleh AlarmManager saat timer habis. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        VolumeService.instance?.island?.timerFinished()
    }
}
