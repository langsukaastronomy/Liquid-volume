package com.example.liquidvolume

import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import android.view.View
import android.widget.FrameLayout
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Bentuk island digambar sendiri dan dianimasikan dengan spring (tanpa relayout tiap frame),
 * jadi gerakannya halus. Jendela hanya diubah ukurannya sebelum/sesudah animasi.
 */
class IslandView(ctx: Context, private val ios: Boolean, private val glass: Boolean) : FrameLayout(ctx) {
    private val d = resources.displayMetrics.density
    var collW = 110 * d
    var collH = 30 * d
    var shapeW = collW
    var shapeH = collH
    var targetW = collW.toInt()
    var targetH = collH.toInt()
    val pad = (10 * d).toInt()
    var tilt = 0f
        set(v) { field = v; if (glass) invalidate() }
    var onWantWindow: ((Int, Int) -> Unit)? = null
    var onSettled: (() -> Unit)? = null
    private var cur: View? = null

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()

    private val wProp = object : FloatPropertyCompat<IslandView>("w") {
        override fun getValue(o: IslandView) = o.shapeW
        override fun setValue(o: IslandView, v: Float) { o.shapeW = v; o.invalidate() }
    }
    private val hProp = object : FloatPropertyCompat<IslandView>("h") {
        override fun getValue(o: IslandView) = o.shapeH
        override fun setValue(o: IslandView, v: Float) { o.shapeH = v; o.invalidate() }
    }
    private val wSpring = SpringAnimation(this, wProp).setSpring(
        SpringForce().setStiffness(if (ios) 380f else 800f).setDampingRatio(if (ios) 0.7f else 1f))
    private val hSpring = SpringAnimation(this, hProp).setSpring(
        SpringForce().setStiffness(if (ios) 300f else 800f).setDampingRatio(if (ios) 0.64f else 1f))

    init {
        setWillNotDraw(false)
        wSpring.addEndListener { _, _, _, _ -> checkSettled() }
        hSpring.addEndListener { _, _, _, _ -> checkSettled() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { pivotX = w / 2f; pivotY = 0f }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
        }
        return super.dispatchTouchEvent(e)
    }

    private fun checkSettled() { if (!wSpring.isRunning && !hSpring.isRunning) onSettled?.invoke() }

    fun setColl(w: Float, h: Float) {
        collW = w; collH = h; shapeW = w; shapeH = h
        targetW = w.toInt(); targetH = h.toInt()
    }

    fun settledW() = targetW + 2 * pad
    fun settledH() = targetH + pad

    fun go(content: View?, tw: Int, th: Int) {
        val nw = if (content == null) collW.toInt() else tw
        val nh = if (content == null) collH.toInt() else max(th, collH.toInt())
        val same = content != null && cur != null && nw == targetW && nh == targetH
        val old = cur
        if (old != null) {
            if (same) removeView(old)
            else old.animate().alpha(0f).setDuration(110).withEndAction { removeView(old) }.start()
        }
        cur = content
        targetW = nw
        targetH = nh
        onWantWindow?.invoke(max(shapeW.toInt(), nw) + 2 * pad, max(shapeH.toInt(), nh) + pad)
        if (content != null) {
            content.alpha = if (same) 1f else 0f
            addView(content, LayoutParams(nw, nh, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            if (!same) content.animate().alpha(1f).setStartDelay(100).setDuration(180).start()
        }
        val need = abs(shapeW - nw) > 0.5f || abs(shapeH - nh) > 0.5f
        if (need) {
            wSpring.animateToFinalPosition(nw.toFloat())
            hSpring.animateToFinalPosition(nh.toFloat())
        } else post { onSettled?.invoke() }
    }

    private fun maxR() = (if (ios || glass) 34f else 26f) * d

    override fun onDraw(c: Canvas) {
        val l = (width - shapeW) / 2f
        rect.set(l, 0f, l + shapeW, shapeH)
        val r = min(shapeH / 2f, maxR())
        if (glass) {
            gp.shader = LinearGradient(0f, 0f, 0f, shapeH, Color.argb(205, 24, 24, 30), Color.argb(150, 0, 0, 0), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, r, r, gp)
            c.save()
            clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
            gp.shader = RadialGradient(l + shapeW * (0.5f + 0.45f * tilt), shapeH * 0.2f,
                max(shapeW, shapeH) * 0.55f, Color.argb(100, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(rect, gp)
            gp.shader = LinearGradient(l, 0f, l + shapeW, shapeH,
                intArrayOf(Color.argb(45, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(28, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(rect, gp)
            c.restore()
            gp.shader = null
            rim.strokeWidth = 1.3f * d
            rim.shader = LinearGradient(l, 0f, l + shapeW, shapeH,
                intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(40, 255, 255, 255), Color.argb(170, 255, 255, 255)),
                floatArrayOf(0f, (0.5f + 0.4f * tilt).coerceIn(0.1f, 0.9f), 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(rect, r, r, rim)
        } else {
            c.drawRoundRect(rect, r, r, bg)
            if (ios) {
                rim.shader = null
                rim.strokeWidth = 3f * d
                rim.color = Color.argb(14, 255, 255, 255)
                rect.inset(1.5f * d, 1.5f * d)
                c.drawRoundRect(rect, r, r, rim)
                rim.strokeWidth = 1f * d
                rim.color = Color.argb(60, 255, 255, 255)
                rect.inset(-1f * d, -1f * d)
                c.drawRoundRect(rect, r, r, rim)
            }
        }
    }

    override fun dispatchDraw(c: Canvas) {
        val l = (width - shapeW) / 2f
        rect.set(l, 0f, l + shapeW, shapeH)
        val r = min(shapeH / 2f, maxR())
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        super.dispatchDraw(c)
        c.restore()
    }
}
