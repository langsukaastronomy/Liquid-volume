package com.example.liquidvolume

import android.graphics.*
import android.graphics.drawable.Drawable

/**
 * Gaya Liquid Glass untuk layar utama (hanya tampilan, bukan tata letak).
 * Sengaja memakai Drawable statis (gradient + garis kilau) tanpa blur realtime
 * supaya tetap ringan di HP spek rendah.
 */
object Glass {
    const val BASE = 0xFF0C0B0E.toInt()

    /** Latar gelap dengan cahaya warna lembut di belakang kaca. */
    class Backdrop : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            c.drawColor(BASE)
            blob(c, w * 0.10f, h * 0.06f, w * 0.85f, 0x553B82F6)
            blob(c, w * 0.98f, h * 0.38f, w * 0.80f, 0x448B5CF6)
            blob(c, w * 0.05f, h * 0.70f, w * 0.75f, 0x330EA5A4)
            blob(c, w * 0.90f, h * 0.98f, w * 0.80f, 0x403B82F6)
        }
        private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
            p.shader = RadialGradient(x, y, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, r, p)
        }
        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: ColorFilter?) {}
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.OPAQUE
    }

    /** Panel kaca: isi tembus pandang, kilau atas, dan tepi terang diagonal. */
    class Panel(
        private val radiusPx: Float,
        private val density: Float,
        private val accent: Int = 0,      // 0 = kaca bening; selain itu = kaca bertint
        private val strong: Boolean = false,
        private val tintTop: Int = 0xB0,
        private val tintBot: Int = 0x80
    ) : Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val spec = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val rect = RectF()
        private var r = radiusPx

        override fun onBoundsChange(b: Rect) {
            val sw = if (strong) 1.6f * density else 1f * density
            rim.strokeWidth = sw
            spec.strokeWidth = 1f * density
            rect.set(b.left + sw / 2, b.top + sw / 2, b.right - sw / 2, b.bottom - sw / 2)
            r = minOf(radiusPx, rect.height() / 2f)
            fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
                intArrayOf(0x2EFFFFFF, 0x12FFFFFF, 0x1AFFFFFF), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
            if (accent != 0) {
                val a = accent and 0x00FFFFFF
                tint.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
                    (tintTop shl 24) or a, (tintBot shl 24) or a, Shader.TileMode.CLAMP)
            }
            val hi = if (strong || accent != 0) 0xFF else 0xB8
            rim.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom,
                intArrayOf((hi shl 24) or 0xFFFFFF, 0x24FFFFFF, 0x10FFFFFF, 0x66FFFFFF),
                floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
            val y = rect.top + 1.5f * density
            val x0 = rect.left + r * 0.8f
            val x1 = rect.right - r * 0.8f
            spec.shader = LinearGradient(x0, y, x1, y,
                intArrayOf(0x00FFFFFF, 0x99FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        }

        override fun draw(c: Canvas) {
            if (rect.isEmpty) return
            c.drawRoundRect(rect, r, r, fill)
            if (accent != 0) c.drawRoundRect(rect, r, r, tint)
            val y = rect.top + 1.5f * density
            c.drawLine(rect.left + r * 0.8f, y, rect.right - r * 0.8f, y, spec)
            c.drawRoundRect(rect, r, r, rim)
        }

        override fun setAlpha(a: Int) {}
        override fun setColorFilter(f: ColorFilter?) {}
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.TRANSLUCENT
    }
}
