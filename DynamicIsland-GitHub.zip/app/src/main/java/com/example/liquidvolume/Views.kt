package com.example.liquidvolume

import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.Path
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.LinearInterpolator
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** Batang equalizer / gelombang suara yang bergerak halus. */
class BarsView(ctx: Context, col: Int, private val bars: Int, wDp: Int, hDp: Int) : View(ctx) {
    var active = true
    private val d = resources.displayMetrics.density
    private val w = (wDp * d).toInt()
    private val h = (hDp * d).toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onMeasure(a: Int, b: Int) = setMeasuredDimension(w, h)
    override fun onDraw(c: Canvas) {
        val bw = w / (bars * 2f - 1f)
        for (i in 0 until bars) {
            val f = if (active) 0.28f + 0.72f * abs(sin(2.0 * PI * (t + i * 0.21)).toFloat()) else 0.28f
            val bh = h * f
            val x = i * bw * 2f
            c.drawRoundRect(x, (h - bh) / 2f, x + bw, (h + bh) / 2f, bw / 2f, bw / 2f, p)
        }
    }
}

/** Teks yang memperbarui dirinya tiap detik (timer, durasi telepon, posisi lagu). */
class TickText(ctx: Context, private val supplier: () -> String) : TextView(ctx) {
    private val r = object : Runnable {
        override fun run() { text = supplier(); postDelayed(this, 1000) }
    }
    init { fontFeatureSettings = "tnum" }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); r.run() }
    override fun onDetachedFromWindow() { removeCallbacks(r); super.onDetachedFromWindow() }
}

/** Progress bar lagu. */
class BarProgress(ctx: Context, private val supplier: () -> Float) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rr = RectF()
    private val r = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 250) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); r.run() }
    override fun onDetachedFromWindow() { removeCallbacks(r); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val h = 4 * d
        val top = (height - h) / 2f
        p.color = Color.argb(70, 255, 255, 255)
        rr.set(0f, top, width.toFloat(), top + h)
        c.drawRoundRect(rr, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        rr.right = width * supplier().coerceIn(0f, 1f)
        c.drawRoundRect(rr, h / 2f, h / 2f, p)
    }
}

/** Progress lagu berbentuk gelombang (batang), bagian yang sudah diputar berwarna putih. */
class WaveProgress(ctx: Context, private val supplier: () -> Float) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 200) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); r.run() }
    override fun onDetachedFromWindow() { removeCallbacks(r); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val bw = 2.5f * d
        val gap = 2f * d
        val n = ((width + gap) / (bw + gap)).toInt().coerceAtLeast(1)
        val prog = supplier().coerceIn(0f, 1f) * n
        for (i in 0 until n) {
            val f = 0.3f + 0.7f * abs(sin(i * 0.83) * kotlin.math.cos(i * 0.31)).toFloat()
            val bh = height * f
            val x = i * (bw + gap)
            p.color = if (i < prog) Color.WHITE else Color.argb(80, 255, 255, 255)
            c.drawRoundRect(x, (height - bh) / 2f, x + bw, (height + bh) / 2f, bw / 2f, bw / 2f, p)
        }
    }
}

/**
 * Tombol media ala iOS: ikon vektor membulat, mengecil saat ditekan lalu membal,
 * getar halus, dan transisi putar/jeda yang "pop".
 */
class MediaButton(ctx: Context, private var kind: Int, private val factor: Float,
                  private val onTap: (MediaButton) -> Unit) : View(ctx) {
    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 0.06f
        pathEffect = CornerPathEffect(0.08f)
    }
    private val p = Path()
    private val r = RectF()
    private var old = -1
    private var swap = 1f
    private var press = 0f
    private var down = false

    fun setKind(k: Int) {
        if (k == kind) return
        old = kind
        kind = k
        swap = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260
            interpolator = OvershootInterpolator(1.6f)
            addUpdateListener { swap = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun animPress(to: Float, ms: Long, ip: TimeInterpolator) {
        ValueAnimator.ofFloat(press, to).apply {
            duration = ms
            interpolator = ip
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height) * factor
        val k = 1f - 0.18f * press
        c.save()
        c.translate(width / 2f, height / 2f)
        c.scale(s * k, s * k)
        val dim = 1f - 0.3f * press.coerceIn(0f, 1f)
        if (old >= 0 && swap < 1f) {
            shape(c, old, 1f - swap, dim)
            shape(c, kind, swap, dim)
        } else {
            shape(c, kind, 1f, dim)
        }
        c.restore()
    }

    private fun shape(c: Canvas, k: Int, a: Float, dim: Float) {
        fp.alpha = (255 * a.coerceIn(0f, 1f) * dim).toInt()
        c.save()
        val sc = 0.5f + 0.5f * a
        c.scale(sc, sc)
        if (k == PREV) c.scale(-1f, 1f)
        when (k) {
            PLAY -> {
                p.reset()
                p.moveTo(-.2f, -.36f); p.lineTo(-.2f, .36f); p.lineTo(.36f, 0f); p.close()
                c.drawPath(p, fp)
            }
            PAUSE -> {
                r.set(-.27f, -.33f, -.07f, .33f)
                c.drawRoundRect(r, .08f, .08f, fp)
                r.set(.07f, -.33f, .27f, .33f)
                c.drawRoundRect(r, .08f, .08f, fp)
            }
            PREV, NEXT -> {
                p.reset()
                p.moveTo(-.44f, -.3f); p.lineTo(-.44f, .3f); p.lineTo(-.02f, 0f); p.close()
                p.moveTo(-.02f, -.3f); p.lineTo(-.02f, .3f); p.lineTo(.4f, 0f); p.close()
                c.drawPath(p, fp)
            }
        }
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                animPress(1f, 90, DecelerateInterpolator())
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            }
            MotionEvent.ACTION_UP -> {
                if (down) {
                    animPress(0f, 340, OvershootInterpolator(3f))
                    if (e.x >= 0f && e.x <= width && e.y >= 0f && e.y <= height) onTap(this)
                }
                down = false
            }
            MotionEvent.ACTION_CANCEL -> {
                animPress(0f, 200, DecelerateInterpolator())
                down = false
            }
        }
        return true
    }
}
