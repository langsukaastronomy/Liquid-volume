package com.example.liquidvolume

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.hardware.Sensor
import android.view.Choreographer
import android.view.animation.OvershootInterpolator
import kotlin.math.roundToInt
import android.hardware.camera2.CameraManager
import android.net.TrafficStats
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Mengelola jendela Dynamic Island: pil idle, kejadian sesaat (kartu) dan aktivitas langsung (musik, navigasi, telepon, timer). */
class Island(private val svc: AccessibilityService) : SensorEventListener {
    companion object { const val K_MUSIC = 0; const val K_TIMER = 1; const val K_NAV = 2; const val K_CALL = 3
        const val K_DL = -1; const val K_TORCH = -2; const val K_SPEED = -3; const val K_FPS = -4; const val K_CHARGE = -5; const val K_REC = 5 }

    private class Live(val key: String, val compact: () -> Pair<View, Float>, val expanded: () -> Triple<View, Float, Float>)
    private class Act(val label: CharSequence, val keep: Boolean, val run: () -> Unit)

    private val d = svc.resources.displayMetrics.density
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val sm = svc.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: IslandView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val lives = HashMap<Int, Live>()
    private var transientActive = false
    private var liveExpanded = false
    private var pendingRemove = false
    private var sensorOn = false
    private var tilt = 0f
    private var lastWifi = 0L
    private var ready = false
    private var lastMusicTitle: String? = null
    var musicCtl: MediaController? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var collW = 0f
    private var collH = 0f
    private var cutX = 0f
    private var topY = 0
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val GREEN = Color.parseColor("#30D158")
    private val GREY = Color.parseColor("#B0B0B8")

    private val endTransient = Runnable { transientActive = false; setFocusable(false); settle() }
    private val collapseLive = Runnable { liveExpanded = false; settle() }
    private val dropMusic = Runnable { lives.remove(K_MUSIC); settle() }
    private var batLvl = 0
    private var plugged = false
    private val power = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batLvl = l * 100 / sc
            val p = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            handler.post { onPlugChanged(p) }
        }
    }
    private val torchIds = HashSet<String>()
    private var camMgr: CameraManager? = null
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            val was = torchIds.isNotEmpty()
            if (enabled) torchIds.add(cameraId) else torchIds.remove(cameraId)
            handler.post { syncTorch(!was && torchIds.isNotEmpty()) }
        }
    }
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var dn = 0.0
    private var up = 0.0

    init {
        try { svc.registerReceiver(power, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (_: Throwable) {}
        try {
            val cm = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            camMgr = cm
            cm.registerTorchCallback(torchCb, handler)
        } catch (_: Throwable) {}
        try {
            val cm = svc.getSystemService(ConnectivityManager::class.java)
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (ready) showWifi() }
            }
            cm.registerNetworkCallback(req, cb)
            netCb = cb
        } catch (_: Throwable) {}
        handler.postDelayed({ ready = true }, 3000)
        handler.post { syncIndicators(); settle() }
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        try { svc.unregisterReceiver(power) } catch (_: Throwable) {}
        try { camMgr?.unregisterTorchCallback(torchCb) } catch (_: Throwable) {}
        stopFps()
        try { netCb?.let { svc.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (_: Throwable) {}
        removeView()
    }

    fun refresh() {
        handler.post {
            transientActive = false
            liveExpanded = false
            removeView()
            syncIndicators()
            settle()
        }
    }

    private fun dp(x: Float) = (x * d).toInt()

    // ---------- sensor kemiringan (Liquid Glass) ----------
    private fun startSensor() {
        if (sensorOn) return
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
        sensorOn = true
    }

    private fun stopSensor() {
        if (!sensorOn) return
        sm.unregisterListener(this)
        sensorOn = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val target = (-e.values[0] / 6f).coerceIn(-1f, 1f)
        tilt += (target - tilt) * 0.12f
        view?.tilt = tilt
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // ---------- jendela ----------
    private fun readCutout() {
        val wpx = svc.resources.displayMetrics.widthPixels
        val hpx = svc.resources.displayMetrics.heightPixels
        var cw = 0f
        var ch = 0f
        var ctop = -1f
        var cx = 0f
        try {
            @Suppress("DEPRECATION")
            val r = wm.defaultDisplay.cutout?.boundingRects?.firstOrNull { it.top < hpx / 8 && it.width() < wpx / 2 }
            if (r != null) {
                cw = r.width().toFloat(); ch = r.height().toFloat()
                ctop = r.top.toFloat(); cx = r.exactCenterX() - wpx / 2f
            }
        } catch (_: Throwable) {}
        collW = max(if (cw > 0f) cw + dp(18f) else dp(112f).toFloat(), dp(96f).toFloat())
        collH = (if (ch > 0f) ch + dp(4f) else dp(30f).toFloat()).coerceIn(dp(24f).toFloat(), dp(44f).toFloat())
        cutX = cx
        topY = if (ctop >= 0f) (ctop - dp(2f)).toInt().coerceAtLeast(0) else dp(8f)
        when (Prefs.camShape(svc)) {
            1 -> { cutX = -wpx / 2f + dp(64f); topY = dp(8f); collW = dp(112f).toFloat(); collH = dp(30f).toFloat() }
            2 -> { cutX = 0f; topY = 0; collW = max(collW, dp(96f).toFloat()); collH = max(collH, dp(34f).toFloat()) }
        }
        // penyesuaian dari pengguna
        collW = (collW + dp(Prefs.adj(svc, "dw").toFloat())).coerceAtLeast(dp(60f).toFloat())
        collH = (collH + dp(Prefs.adj(svc, "dh").toFloat())).coerceIn(dp(18f).toFloat(), dp(60f).toFloat())
        cutX += dp(Prefs.adj(svc, "dx").toFloat())
        topY = (topY + dp(Prefs.adj(svc, "dy").toFloat())).coerceAtLeast(0)
    }

    private fun ensureView(): IslandView? {
        view?.let { return it }
        if (!Prefs.islandOn(svc)) return null
        readCutout()
        val glass = Prefs.islandGlass(svc)
        val v = IslandView(svc, Prefs.islandMode(svc) == 1, glass)
        v.setColl(collW, collH)
        val p = WindowManager.LayoutParams(
            v.settledW(), v.settledH(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        p.x = cutX.toInt()
        p.y = topY
        v.onWantWindow = { w, h -> applyWindow(w, h) }
        v.onSettled = {
            applyWindow(v.settledW(), v.settledH())
            if (pendingRemove) removeView()
        }
        try { wm.addView(v, p) } catch (_: Exception) { return null }
        view = v
        lp = p
        if (glass) startSensor()
        return v
    }

    private fun applyWindow(w: Int, h: Int) {
        val p = lp ?: return
        val v = view ?: return
        val maxOff = svc.resources.displayMetrics.widthPixels / 2 - w / 2
        val nx = if (maxOff >= 0) cutX.toInt().coerceIn(-maxOff, maxOff) else 0
        if (p.width == w && p.height == h && p.x == nx) return
        p.width = w
        p.height = h
        p.x = nx
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun setFocusable(on: Boolean) {
        val p = lp ?: return
        val v = view ?: return
        val f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val nf = if (on) p.flags and f.inv() else p.flags or f
        if (nf == p.flags) return
        p.flags = nf
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun removeView() {
        killOverlays()
        stopSensor()
        val v = view ?: return
        view = null
        lp = null
        pendingRemove = false
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun go(content: View?, twDp: Float, thDp: Float) {
        val v = ensureView() ?: return
        val sw = svc.resources.displayMetrics.widthPixels
        v.go(content, min(dp(twDp), sw - dp(16f)), dp(thDp))
    }

    // ---------- keadaan ----------
    private fun setIslandTap(l: (() -> Unit)?) {
        val v = view ?: return
        if (l == null) {
            v.setOnClickListener(null)
            v.isClickable = false
        } else {
            v.setOnClickListener { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); l() }
        }
    }

    private fun cw(extraDp: Float) = collW / d + extraDp

    private fun collapseNow() {
        handler.removeCallbacks(collapseLive)
        liveExpanded = false
        settle()
    }

    private fun showIdle(tap: (() -> Unit)?) {
        if (Prefs.islandIdle(svc)) {
            go(null, 0f, 0f)
            setIslandTap(tap)
        } else {
            val v = view
            if (v != null) { pendingRemove = true; v.go(null, 0, 0); setIslandTap(null) }
        }
    }

    private fun settle() {
        if (!Prefs.islandOn(svc)) { removeView(); return }
        if (transientActive) return
        pendingRemove = false
        if (collW == 0f) readCutout()
        val sorted = lives.entries.sortedByDescending { it.key }
        val top = sorted.firstOrNull()
        if (top != null) {
            if (liveExpanded) {
                hideBubble()
                showStack(sorted.take(3))
                showIdle(null)
            } else {
                hideStack()
                val c = top.value.compact()
                c.first.setOnClickListener { expandLive(8000L) }
                go(c.first, c.second, 34f)
                setIslandTap(null)
                val sw = svc.resources.displayMetrics.widthPixels
                val pw = min(dp(c.second), sw - dp(16f))
                val second = sorted.getOrNull(1)
                if (second != null) showBubble(second.key, pw) else hideBubble()
            }
        } else {
            hideStack()
            hideBubble()
            showIdle { showQuick() }
        }
    }

    private fun expandLive(ms: Long) {
        liveExpanded = true
        handler.removeCallbacks(collapseLive)
        handler.postDelayed(collapseLive, ms)
        settle()
    }

    private fun present(content: View, tw: Float, th: Float, hold: Long) {
        if (!Prefs.islandOn(svc)) return
        handler.removeCallbacks(endTransient)
        hideStack()
        hideBubble()
        transientActive = true
        go(content, tw, th)
        setIslandTap { endNow() }
        handler.postDelayed(endTransient, hold)
    }

    private fun endNow() {
        handler.removeCallbacks(endTransient)
        transientActive = false
        setFocusable(false)
        settle()
    }

    // ---------- pembangun tampilan ----------
    private fun label(t: CharSequence?, sp: Float, col: Int, bold: Boolean, lines: Int) = TextView(svc).apply {
        text = t ?: ""; textSize = sp; setTextColor(col); maxLines = lines
        ellipsize = TextUtils.TruncateAt.END
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun roundIcon(dr: Drawable?, sizeDp: Float) = ImageView(svc).apply {
        setImageDrawable(dr)
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = GradientDrawable().apply { cornerRadius = sizeDp * d * 0.28f; setColor(Color.parseColor("#2A2A2E")) }
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun pill(txt: CharSequence, col: Int = Color.parseColor("#2C2C31"), onClick: () -> Unit) = TextView(svc).apply {
        text = txt; setTextColor(Color.WHITE); textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(10f), 0, dp(10f), 0)
        background = GradientDrawable().apply { cornerRadius = 100f * d; setColor(col) }
        layoutParams = LinearLayout.LayoutParams(0, dp(34f), 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) }
        setOnClickListener { onClick() }
    }

    private fun sideViews(left: View, right: View): View {
        val f = FrameLayout(svc)
        f.addView(left, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(16f) })
        f.addView(right, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(16f) })
        return f
    }

    private fun sideRow(l: String, r: String, lc: Int, rc: Int) =
        sideViews(label(l, 14f, lc, true, 1), label(r, 14f, rc, true, 1))

    private fun card(icon: Drawable?, title: CharSequence?, text: CharSequence?, acts: List<Act>,
                     tap: (() -> Unit)?, extra: View? = null): Pair<View, Float> {
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
        }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(roundIcon(icon, 44f))
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
        }
        col.addView(label(title, 15f, Color.WHITE, true, 1))
        if (extra != null) col.addView(extra) else col.addView(label(text, 13f, GREY, false, 2))
        row.addView(col)
        root.addView(row)
        if (acts.isNotEmpty()) {
            val ar = LinearLayout(svc).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34f)).apply { topMargin = dp(10f) }
            }
            acts.forEach { a -> ar.addView(pill(a.label) { a.run(); if (!a.keep) endNow() }) }
            root.addView(ar)
        }
        if (tap != null) root.setOnClickListener { tap() }
        return Pair(root, if (acts.isEmpty()) 88f else 134f)
    }

    private fun appIcon(sbn: StatusBarNotification): Drawable? {
        try { sbn.notification.getLargeIcon()?.let { return it.loadDrawable(svc) } } catch (_: Throwable) {}
        try { return svc.packageManager.getApplicationIcon(sbn.packageName) } catch (_: Throwable) {}
        try { sbn.notification.smallIcon?.let { return it.loadDrawable(svc) } } catch (_: Throwable) {}
        return null
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val ss = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, ss) else String.format(Locale.US, "%d:%02d", m, ss)
    }

    private fun tapOf(sbn: StatusBarNotification): (() -> Unit)? {
        val pi = sbn.notification.contentIntent ?: return null
        return { try { pi.send() } catch (_: Exception) {}; endNow(); liveExpanded = false; settle() }
    }

    private fun actsOf(sbn: StatusBarNotification, max: Int, replyIcon: Drawable?): List<Act> {
        val out = ArrayList<Act>()
        val ex = sbn.notification.extras
        (sbn.notification.actions ?: emptyArray()).forEach { a ->
            val pi = a.actionIntent
            val t = a.title
            if (pi == null || t.isNullOrBlank() || out.size >= max) return@forEach
            val ri = a.remoteInputs
            if (ri != null && ri.isNotEmpty()) {
                out.add(Act(t, true) {
                    openReply(replyIcon, ex.getCharSequence(Notification.EXTRA_TITLE),
                        ex.getCharSequence(Notification.EXTRA_TEXT)) { msg ->
                        try {
                            val i = Intent()
                            val b = Bundle()
                            b.putCharSequence(ri[0].resultKey, msg)
                            RemoteInput.addResultsToIntent(ri, i, b)
                            pi.send(svc, 0, i)
                        } catch (_: Throwable) {}
                    }
                })
            } else {
                out.add(Act(t, false) { try { pi.send() } catch (_: Exception) {} })
            }
        }
        return out
    }

    // ---------- kartu notifikasi + balas ----------
    fun showNotification(sbn: StatusBarNotification, isCall: Boolean) {
        handler.post {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)
            val text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)
            if (title == null && text == null) return@post
            val icon = appIcon(sbn)
            val built = card(icon, title, text, actsOf(sbn, 2, icon), tapOf(sbn))
            present(built.first, 340f, built.second, if (isCall) 25000L else 5000L)
        }
    }

    private fun openReply(icon: Drawable?, title: CharSequence?, text: CharSequence?, onSend: (String) -> Unit) {
        endNow()
        ReplyBridge.icon = icon
        ReplyBridge.title = title
        ReplyBridge.text = text
        ReplyBridge.topY = topY
        ReplyBridge.onSend = onSend
        try {
            svc.startActivity(Intent(svc, ReplyActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        } catch (_: Throwable) {
            handler.post { present(sideRow("Gagal buka balas", "", GREY, GREY), 260f, 36f, 2000L) }
        }
    }

    fun note(t: String) {
        handler.post { present(sideRow(t, "", GREY, GREY), 300f, 36f, 2500L) }
    }

    fun sentToast() {
        handler.post { present(sideRow("✓ Terkirim", "", GREEN, GREEN), 220f, 36f, 1300L) }
    }

    // ---------- charging, wifi, demo ----------
    fun showCharging() {
        handler.post {
            val i = svc.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val scale = (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
            present(sideRow("⚡ Charging", "${lvl * 100 / scale}%", GREEN, GREEN), 250f, 36f, 3000L)
        }
    }

    private fun ssid(): String? = try {
        if (svc.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) null
        else {
            @Suppress("DEPRECATION")
            val s = (svc.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo?.ssid?.trim('"')
            if (s == null || s == "<unknown ssid>") null else s
        }
    } catch (_: Throwable) { null }

    fun showWifi() {
        handler.post {
            val now = System.currentTimeMillis()
            if (now - lastWifi < 10000) return@post
            lastWifi = now
            present(sideRow(ssid() ?: "Wi-Fi", "Connected", Color.WHITE, Color.parseColor("#0A84FF")), 270f, 36f, 2500L)
        }
    }

    fun demo() {
        handler.post {
            val icon = try { svc.packageManager.getApplicationIcon(svc.packageName) } catch (_: Throwable) { null }
            val acts = listOf(
                Act("Balas", true) { openReply(icon, "Anna", "Hei! Lihat island-nya sekarang 👋") { } },
                Act("Tandai dibaca", false) { }
            )
            val built = card(icon, "Anna", "Hei! Lihat island-nya sekarang 👋", acts, null)
            present(built.first, 340f, built.second, 6000L)
        }
    }

    // ---------- indikator menetap (charging, kecepatan internet, senter, rekam layar) ----------
    private fun onPlugChanged(p: Boolean) {
        if (p == plugged) return
        plugged = p
        if (p && ready) showCharging()
        syncIndicators()
        settle()
    }

    private fun syncIndicators() {
        if (plugged && Prefs.persistCharge(svc)) setChargeLive() else lives.remove(K_CHARGE)
        if (Prefs.speedOn(svc)) setSpeedLive() else lives.remove(K_SPEED)
        if (Prefs.fpsOn(svc)) setFpsLive() else { stopFps(); lives.remove(K_FPS) }
        if (torchIds.isNotEmpty() && Prefs.torchInd(svc)) setTorchLive() else lives.remove(K_TORCH)
    }

    private fun syncTorch(justOn: Boolean) {
        if (torchIds.isNotEmpty() && Prefs.torchInd(svc)) {
            setTorchLive()
            if (justOn) expandLive(5000L) else settle()
        } else {
            if (lives.remove(K_TORCH) != null) { liveExpanded = false; settle() }
        }
    }

    private fun setChargeLive() {
        lives[K_CHARGE] = Live("charge", {
            val pct = TickText(svc) { "$batLvl%" }.apply { textSize = 14f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD) }
            Pair(sideViews(label("⚡", 16f, GREEN, true, 1), pct), cw(74f))
        }, {
            val root = LinearLayout(svc).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            }
            val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(label("⚡ Mengisi daya", 15f, GREEN, true, 1).apply {
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            })
            row.addView(TickText(svc) { "$batLvl%" }.apply { textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) })
            root.addView(row)
            root.addView(BarProgress(svc) { batLvl / 100f }.apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(14f)).apply { topMargin = dp(10f) }
            })
            Triple(root, 340f, 96f)
        })
    }

    private fun sampleSpeed() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastT < 800L) return
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (lastT > 0L && rx >= 0L && tx >= 0L) {
            val dt = (now - lastT) / 1000.0
            dn = ((rx - lastRx) / dt).coerceAtLeast(0.0)
            up = ((tx - lastTx) / dt).coerceAtLeast(0.0)
        }
        lastRx = rx; lastTx = tx; lastT = now
    }

    private fun rate(b: Double): String = when {
        b >= 1048576.0 -> String.format(Locale.US, "%.1f MB/s", b / 1048576.0)
        b >= 1024.0 -> String.format(Locale.US, "%.0f KB/s", b / 1024.0)
        else -> String.format(Locale.US, "%.0f B/s", b)
    }

    private fun setSpeedLive() {
        val blue = Color.parseColor("#0A84FF")
        lives[K_SPEED] = Live("speed", {
            val l = TickText(svc) { sampleSpeed(); "↓ " + rate(dn) }.apply { textSize = 12f; setTextColor(blue); setTypeface(typeface, Typeface.BOLD) }
            val r = TickText(svc) { "↑ " + rate(up) }.apply { textSize = 12f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD) }
            Pair(sideViews(l, r), cw(116f))
        }, {
            val root = LinearLayout(svc).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            }
            root.addView(label("📶 Kecepatan internet", 14f, blue, true, 1))
            root.addView(TickText(svc) { sampleSpeed(); "↓  " + rate(dn) }.apply { textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) })
            root.addView(TickText(svc) { "↑  " + rate(up) }.apply { textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) })
            Triple(root, 340f, 112f)
        })
    }

    private fun torchOff() {
        val cm = camMgr ?: return
        torchIds.toList().forEach { try { cm.setTorchMode(it, false) } catch (_: Throwable) {} }
    }

    private fun setTorchLive() {
        val yellow = Color.parseColor("#FFD60A")
        lives[K_TORCH] = Live("torch", {
            Pair(sideViews(label("🔦", 16f, yellow, true, 1), label("Senter", 13f, yellow, true, 1)), cw(84f))
        }, {
            ctrlCard(null, "Senter", label("Menyala", 18f, yellow, true, 1),
                listOf(Act("Matikan", false) { torchOff() }), null)
        })
    }

    private val recStart = HashMap<String, Long>()

    fun recLive(sbn: StatusBarNotification) {
        handler.post {
            if (!Prefs.recInd(svc)) return@post
            val n = sbn.notification
            val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
            val paused = n.extras.getBoolean("paused")
            val frozen = n.extras.getLong("elapsed", -1L)
            val base = if (chrono && n.`when` > 0L) n.`when` else recStart.getOrPut(sbn.key) { System.currentTimeMillis() }
            val icon = appIcon(sbn)
            val red = Color.parseColor("#FF3B30")
            val dotCol = if (paused) GREY else red
            val timerText: () -> String = {
                if (paused && frozen >= 0L) fmt(frozen) else fmt(System.currentTimeMillis() - base)
            }
            fun dotView(): View {
                val dot = label("●", 12f, dotCol, true, 1)
                if (!paused) dot.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                    var a: ObjectAnimator? = null
                    override fun onViewAttachedToWindow(v: View) {
                        a = ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.25f).apply {
                            duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start()
                        }
                    }
                    override fun onViewDetachedFromWindow(v: View) { a?.cancel() }
                })
                return dot
            }
            lives[K_REC] = Live(sbn.key, {
                val t = TickText(svc, timerText).apply { textSize = 13f; setTextColor(if (paused) Color.WHITE else red); setTypeface(typeface, Typeface.BOLD) }
                Pair(sideViews(dotView(), t), cw(88f))
            }, {
                val sub = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                sub.addView(dotView())
                sub.addView(TickText(svc, timerText).apply {
                    textSize = 20f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(8f), 0, 0, 0)
                })
                ctrlCard(null, null, sub, actsOf(sbn, 3, icon), tapOf(sbn))
            })
            settle()
        }
    }

    // ---------- kartu mengambang, gelembung kedua, tombol bulat ----------
    private var stack: LinearLayout? = null
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null

    private fun killOverlays() {
        stack?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        stack = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        bubbleLp = null
    }

    private fun hideStack() {
        val r = stack ?: return
        stack = null
        r.animate().alpha(0f).scaleX(0.95f).scaleY(0.95f).setDuration(160)
            .withEndAction { try { wm.removeView(r) } catch (_: Exception) {} }.start()
    }

    private fun hideBubble() {
        val b = bubble ?: return
        bubble = null
        bubbleLp = null
        b.animate().alpha(0f).scaleX(0.4f).scaleY(0.4f).setDuration(140)
            .withEndAction { try { wm.removeView(b) } catch (_: Exception) {} }.start()
    }

    private fun showStack(items: List<Map.Entry<Int, Live>>) {
        val sw = svc.resources.displayMetrics.widthPixels
        val w = min(sw - dp(24f), dp(400f))
        var root = stack
        if (root == null) {
            val r = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL }
            r.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) collapseNow()
                false
            }
            val p = WindowManager.LayoutParams(
                w, WRAP,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            p.y = topY + collH.toInt() + dp(8f)
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            try { wm.addView(r, p) } catch (_: Exception) { return }
            stack = r
            root = r
            r.alpha = 0f
            r.scaleX = 0.92f
            r.scaleY = 0.92f
            r.translationY = -dp(10f).toFloat()
            r.pivotX = w / 2f
            r.pivotY = 0f
            r.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(320)
                .setInterpolator(OvershootInterpolator(1.15f)).start()
        }
        val rt = root ?: return
        rt.removeAllViews()
        items.forEachIndexed { i, en ->
            val e = en.value.expanded()
            val h = dp(e.third)
            val card = FrameLayout(svc)
            card.background = GradientDrawable().apply { cornerRadius = dp(28f).toFloat(); setColor(Color.BLACK) }
            card.addView(e.first, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
            rt.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply {
                if (i > 0) topMargin = dp(8f)
            })
        }
    }

    private fun bubbleGlyph(key: Int): Pair<String, Int> = when (key) {
        K_MUSIC -> Pair("♪", Color.parseColor("#FF375F"))
        K_TIMER -> Pair("⏱", AMBER)
        K_NAV -> Pair("➤", GREEN)
        K_CALL -> Pair("✆", GREEN)
        K_REC -> Pair("●", Color.parseColor("#FF3B30"))
        K_DL -> Pair("↓", Color.parseColor("#0A84FF"))
        K_TORCH -> Pair("🔦", Color.parseColor("#FFD60A"))
        K_SPEED -> Pair("⇅", Color.parseColor("#0A84FF"))
        K_FPS -> Pair("◔", GREEN)
        K_CHARGE -> Pair("⚡", GREEN)
        else -> Pair("●", Color.WHITE)
    }

    private fun showBubble(key: Int, pillWpx: Int) {
        val g = bubbleGlyph(key)
        val sz = max(dp(34f), collH.toInt())
        val x = (cutX + pillWpx / 2f + dp(6f) + sz / 2f).toInt()
        var b = bubble
        if (b == null) {
            val t = TextView(svc).apply {
                gravity = Gravity.CENTER
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
                setOnClickListener { expandLive(8000L) }
            }
            val p = WindowManager.LayoutParams(
                sz, sz,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            p.x = x
            p.y = topY
            try { wm.addView(t, p) } catch (_: Exception) { return }
            bubble = t
            bubbleLp = p
            b = t
            t.scaleX = 0.4f; t.scaleY = 0.4f; t.alpha = 0f
            t.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(1.6f)).start()
        } else {
            val p = bubbleLp
            if (p != null && p.x != x) {
                p.x = x
                try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
            }
        }
        val bv = b ?: return
        bv.text = g.first
        bv.setTextColor(g.second)
    }

    private fun glyphFor(t: String): Pair<String, Int> {
        val s = t.lowercase()
        val red = Color.parseColor("#FF453A")
        fun has(vararg k: String) = k.any { s.contains(it) }
        return when {
            has("stop", "hentikan", "berhenti", "selesai") -> Pair("■", red)
            has("akhiri", "tutup", "hang", "tolak", "decline", "reject", "putus", "end") -> Pair("✕", red)
            has("pause", "jeda") -> Pair("❚❚", Color.WHITE)
            has("resume", "lanjut", "play") -> Pair("▶", Color.WHITE)
            has("mute", "bisu", "senyap") -> Pair("🎙", Color.WHITE)
            has("answer", "jawab", "terima", "angkat") -> Pair("✓", GREEN)
            has("matikan", "off") -> Pair("⏻", Color.WHITE)
            else -> Pair(t.take(2), Color.WHITE)
        }
    }

    private fun circleBtn(label: String, onClick: () -> Unit): TextView {
        val g = glyphFor(label)
        val redish = g.second == Color.parseColor("#FF453A")
        return TextView(svc).apply {
            text = g.first
            textSize = 14f
            setTextColor(g.second)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (redish) Color.parseColor("#4A1A1F") else Color.parseColor("#2C2C31"))
            }
            layoutParams = LinearLayout.LayoutParams(dp(42f), dp(42f)).apply { marginStart = dp(8f) }
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
        }
    }

    /** Kartu satu baris ala video: judul kecil + isi besar di kiri, tombol bulat di kanan. */
    private fun ctrlCard(lead: View?, title: CharSequence?, sub: View, acts: List<Act>, tap: (() -> Unit)?): Triple<View, Float, Float> {
        val row = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(10f), dp(14f), dp(10f))
        }
        if (lead != null) row.addView(lead, LinearLayout.LayoutParams(dp(40f), dp(40f)).apply { marginEnd = dp(12f) })
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        if (title != null) col.addView(label(title, 13f, GREY, false, 1))
        col.addView(sub)
        row.addView(col)
        acts.forEach { a -> row.addView(circleBtn(a.label.toString()) { a.run() }) }
        if (tap != null) row.setOnClickListener { tap() }
        return Triple(row, 340f, 68f)
    }

    // ---------- FPS & unduhan ----------
    private var fpsFrames = 0
    private var fpsT = 0L
    private var fpsVal = 0
    private var fpsRunning = false
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!fpsRunning) return
            fpsFrames++
            val now = frameTimeNanos / 1_000_000L
            if (fpsT == 0L) fpsT = now
            if (now - fpsT >= 1000L) {
                fpsVal = (fpsFrames * 1000f / (now - fpsT)).roundToInt()
                fpsFrames = 0
                fpsT = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun startFps() {
        if (fpsRunning) return
        fpsRunning = true
        fpsT = 0L; fpsFrames = 0
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun stopFps() {
        fpsRunning = false
        try { Choreographer.getInstance().removeFrameCallback(frameCb) } catch (_: Throwable) {}
    }

    private fun setFpsLive() {
        startFps()
        lives[K_FPS] = Live("fps", {
            val t = TickText(svc) { "$fpsVal FPS" }.apply { textSize = 12f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD) }
            Pair(sideViews(label("◔", 16f, GREEN, true, 1), t), cw(96f))
        }, {
            val sub = TickText(svc) { "$fpsVal FPS" }.apply { textSize = 22f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD) }
            ctrlCard(null, "Kecepatan frame layar", sub, emptyList(), null)
        })
    }

    fun dlLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val ex = n.extras
            val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
            val cur = ex.getInt(Notification.EXTRA_PROGRESS, 0)
            val indet = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE)
            val pct = if (max > 0 && !indet) (cur * 100L / max).toInt() else -1
            val txt = if (pct >= 0) "$pct%" else "…"
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)
            val icon = appIcon(sbn)
            val blue = Color.parseColor("#0A84FF")
            lives[K_DL] = Live(sbn.key, {
                Pair(sideViews(label("↓", 16f, blue, true, 1), label(txt, 13f, blue, true, 1)), cw(80f))
            }, {
                val sub = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL }
                sub.addView(label(txt, 20f, Color.WHITE, true, 1))
                sub.addView(BarProgress(svc) { if (pct >= 0) pct / 100f else 0f }.apply {
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(10f))
                })
                val t = ctrlCard(roundIcon(icon, 36f), title, sub, emptyList(), tapOf(sbn))
                Triple(t.first, 340f, 76f)
            })
            settle()
        }
    }

    // ---------- aktivitas langsung ----------
    fun removeByKey(key: String) {
        handler.post {
            val hit = lives.entries.firstOrNull { it.value.key == key }
            if (hit != null) { lives.remove(hit.key); recStart.remove(key); settle() }
        }
    }

    // Musik
    private fun pos(c: MediaController): Long {
        val s = c.playbackState ?: return 0L
        var p = s.position
        if (s.state == PlaybackState.STATE_PLAYING) {
            p += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
        }
        return p.coerceAtLeast(0L)
    }

    private fun dur(c: MediaController) = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    fun musicLive(c: MediaController, playing: Boolean) {
        handler.post {
            val title = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return@post
            handler.removeCallbacks(dropMusic)
            musicCtl = c
            lives[K_MUSIC] = Live("music", { musicCompact(c, playing) }, { musicExpanded(c, playing) })
            if (!playing) handler.postDelayed(dropMusic, 20000)
            if (playing && title != lastMusicTitle) { lastMusicTitle = title; expandLive(6000L) } else settle()
        }
    }

    fun musicGone() {
        handler.post {
            handler.removeCallbacks(dropMusic)
            lastMusicTitle = null
            musicCtl = null
            if (lives.remove(K_MUSIC) != null) settle()
        }
    }

    private fun artOf(c: MediaController) = c.metadata?.let {
        it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART)
        ?: it.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    }

    private fun musicCompact(c: MediaController, playing: Boolean): Pair<View, Float> {
        val art = roundIcon(null, 24f)
        artOf(c)?.let { art.setImageBitmap(it) }
        val bars = BarsView(svc, Color.parseColor("#FF375F"), 4, 22, 16).apply { active = playing }
        return Pair(sideViews(art, bars), cw(84f))
    }

    private fun musicExpanded(c: MediaController, playing: Boolean): Triple<View, Float, Float> {
        val m = c.metadata
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(6f))
        }
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val art = roundIcon(null, 52f)
        artOf(c)?.let { art.setImageBitmap(it) }
        row.addView(art)
        val col = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
        }
        col.addView(label(m?.getString(MediaMetadata.METADATA_KEY_TITLE), 15f, Color.WHITE, true, 1))
        col.addView(label(m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST), 13f, GREY, false, 1))
        row.addView(col)
        row.addView(BarsView(svc, Color.parseColor("#FF375F"), 4, 22, 16).apply { active = playing })
        root.addView(row)

        val prog = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22f)).apply { topMargin = dp(8f) }
        }
        val t1 = TickText(svc) { fmt(pos(c)) }.apply { textSize = 11f; setTextColor(GREY) }
        val bar = WaveProgress(svc) { val dd = dur(c); if (dd > 0) pos(c).toFloat() / dd else 0f }
            .apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(dp(8f), 0, dp(8f), 0) } }
        val t2 = TickText(svc) { val dd = dur(c); if (dd > 0) "-" + fmt(dd - pos(c)) else "" }.apply { textSize = 11f; setTextColor(GREY) }
        prog.addView(t1); prog.addView(bar); prog.addView(t2)
        root.addView(prog)

        fun ctl(kind: Int, factor: Float, act: (MediaButton) -> Unit) =
            MediaButton(svc, kind, factor) { btn ->
                try { act(btn) } catch (_: Throwable) {}
                handler.removeCallbacks(collapseLive)
                handler.postDelayed(collapseLive, 6000L)
            }.apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f) }
        val ctrls = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50f)).apply { topMargin = dp(2f) }
        }
        ctrls.addView(ctl(MediaButton.PREV, 0.6f) { c.transportControls.skipToPrevious() })
        ctrls.addView(ctl(if (playing) MediaButton.PAUSE else MediaButton.PLAY, 0.72f) { btn ->
            val now = c.playbackState?.state == PlaybackState.STATE_PLAYING
            if (now) { c.transportControls.pause(); btn.setKind(MediaButton.PLAY) }
            else { c.transportControls.play(); btn.setKind(MediaButton.PAUSE) }
        })
        ctrls.addView(ctl(MediaButton.NEXT, 0.6f) { c.transportControls.skipToNext() })
        root.addView(ctrls)
        return Triple(root, 340f, 158f)
    }

    // Navigasi (notifikasi Google Maps dkk.)
    fun navLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val ex = n.extras
            val dist = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val street = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            val eta = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
            val arrow = try { n.getLargeIcon()?.loadDrawable(svc) } catch (_: Throwable) { null }
            val tap = tapOf(sbn)
            lives[K_NAV] = Live(sbn.key, {
                val left: View = if (arrow != null) ImageView(svc).apply {
                    setImageDrawable(arrow); layoutParams = FrameLayout.LayoutParams(dp(24f), dp(24f))
                } else label("➤", 16f, GREEN, true, 1)
                Pair(sideViews(left, label(dist, 14f, GREEN, true, 1)), cw(96f))
            }, {
                val root = LinearLayout(svc).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16f), dp(14f), dp(16f), dp(12f))
                }
                val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val ic = roundIcon(arrow, 52f)
                ic.setBackgroundColor(Color.parseColor("#12301F"))
                row.addView(ic)
                val col = LinearLayout(svc).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12f) }
                }
                col.addView(label(dist, 22f, Color.WHITE, true, 1))
                col.addView(label(street, 13f, GREY, false, 1))
                row.addView(col)
                root.addView(row)
                val er = LinearLayout(svc).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34f)).apply { topMargin = dp(10f) }
                }
                val etaV = label(eta, 13f, GREEN, true, 1)
                etaV.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                er.addView(etaV)
                val open = pill("Buka", Color.parseColor("#1F8F45")) { tap?.invoke() }
                open.layoutParams = LinearLayout.LayoutParams(dp(84f), dp(34f))
                er.addView(open)
                root.addView(er)
                Triple(root, 340f, 128f)
            })
            settle()
        }
    }

    // Telepon berlangsung
    fun callLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val base = n.`when`
            val name = n.extras.getCharSequence(Notification.EXTRA_TITLE)
            val icon = appIcon(sbn)
            lives[K_CALL] = Live(sbn.key, {
                val left = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                left.addView(label("📞 ", 13f, GREEN, true, 1))
                left.addView(TickText(svc) { fmt(System.currentTimeMillis() - base) }.apply {
                    textSize = 14f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD)
                })
                Pair(sideViews(left, BarsView(svc, GREEN, 5, 28, 16)), cw(100f))
            }, {
                val timer = TickText(svc) { fmt(System.currentTimeMillis() - base) }.apply {
                    textSize = 18f; setTextColor(GREEN); setTypeface(typeface, Typeface.BOLD)
                }
                ctrlCard(roundIcon(icon, 36f), name, timer, actsOf(sbn, 3, icon), tapOf(sbn))
            })
            settle()
        }
    }

    // Timer / stopwatch (notifikasi chronometer)
    fun timerLive(sbn: StatusBarNotification) {
        handler.post {
            val n = sbn.notification
            val base = n.`when`
            val down = n.extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN)
            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)
            val icon = appIcon(sbn)
            val amber = Color.parseColor("#FF9F0A")
            val value: () -> String = {
                val now = System.currentTimeMillis()
                fmt(if (down) base - now else now - base)
            }
            lives[K_TIMER] = Live(sbn.key, {
                val t = TickText(svc, value).apply { textSize = 14f; setTextColor(amber); setTypeface(typeface, Typeface.BOLD) }
                Pair(sideViews(label("⏱", 16f, amber, true, 1), t), cw(84f))
            }, {
                val t = TickText(svc, value).apply { textSize = 20f; setTextColor(amber); setTypeface(typeface, Typeface.BOLD) }
                val b = card(icon, title, null, actsOf(sbn, 2, icon), tapOf(sbn), t)
                Triple(b.first, 340f, b.second)
            })
            settle()
        }
    }

    // ---------- timer sendiri + panel cepat (tap pil) ----------
    private var timerAt = 0L
    private var ringtone: Ringtone? = null
    private val timerDone = Runnable { timerFinished() }
    private val stopAlarmR = Runnable { stopAlarm() }
    private val refreshR = Runnable { transientActive = false; liveExpanded = false; removeView(); settle() }
    private val AMBER = Color.parseColor("#FF9F0A")

    fun refreshSoon() {
        handler.removeCallbacks(refreshR)
        handler.postDelayed(refreshR, 150)
    }

    // Tap pil -> langsung pengatur timer manual (jam / menit / detik), tanpa pilihan saran.
    private fun showQuick() { showTimerPicker() }

    private var pickH = 0
    private var pickM = 5
    private var pickS = 0

    private fun repeatBtn(glyph: String, act: () -> Unit): TextView {
        val b = TextView(svc)
        b.text = glyph
        b.textSize = 18f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(20f), dp(2f), dp(20f), dp(2f))
        val rep = object : Runnable {
            override fun run() { act(); handler.postDelayed(this, 110) }
        }
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { act(); handler.postDelayed(rep, 380) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(rep)
            }
            true
        }
        return b
    }

    private fun showTimerPicker() {
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
        }
        root.addView(label("⏱ Atur timer", 15f, AMBER, true, 1))
        val row = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(92f)).apply { topMargin = dp(4f) }
        }
        fun unitCol(name: String, get: () -> Int, set: (Int) -> Unit, max: Int) {
            val box = LinearLayout(svc).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            }
            val value = label(String.format(Locale.US, "%02d", get()), 26f, Color.WHITE, true, 1)
            value.gravity = Gravity.CENTER
            fun step(dlt: Int) {
                val n = max + 1
                val v = ((get() + dlt) % n + n) % n
                set(v)
                value.text = String.format(Locale.US, "%02d", v)
            }
            value.setPadding(dp(14f), dp(4f), dp(14f), dp(4f))
            // geser atas/bawah di angka untuk mengubah cepat
            var lastY = 0f
            var acc = 0f
            value.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lastY = e.rawY; acc = 0f }
                    MotionEvent.ACTION_MOVE -> {
                        acc += lastY - e.rawY
                        lastY = e.rawY
                        val stepPx = dp(16f).toFloat()
                        while (acc >= stepPx) { step(1); acc -= stepPx }
                        while (acc <= -stepPx) { step(-1); acc += stepPx }
                    }
                }
                true
            }
            box.addView(repeatBtn("▲") { step(1) })
            box.addView(value)
            box.addView(repeatBtn("▼") { step(-1) })
            box.addView(label(name, 10f, GREY, false, 1))
            row.addView(box)
        }
        unitCol("jam", { pickH }, { pickH = it }, 23)
        unitCol("menit", { pickM }, { pickM = it }, 59)
        unitCol("detik", { pickS }, { pickS = it }, 59)
        root.addView(row)
        val btns = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36f)).apply { topMargin = dp(8f) }
        }
        btns.addView(pill("Batal") { endNow() })
        btns.addView(pill("Mulai", Color.parseColor("#1F8F45")) {
            val total = pickH * 3600L + pickM * 60L + pickS
            if (total > 0L) startTimerSec(total)
        })
        root.addView(btns)
        present(root, 340f, 196f, 40000L)
    }

    private fun alarmPi() = PendingIntent.getBroadcast(
        svc, 91, Intent(svc, TimerReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun scheduleTimer() {
        handler.removeCallbacks(timerDone)
        handler.postDelayed(timerDone, (timerAt - System.currentTimeMillis()).coerceAtLeast(0L))
        try {
            svc.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timerAt, alarmPi())
        } catch (_: Throwable) {}
    }

    private fun startTimer(min: Int) = startTimerSec(min * 60L)

    private fun startTimerSec(sec: Long) {
        timerAt = System.currentTimeMillis() + sec * 1000L
        scheduleTimer()
        lives[K_TIMER] = Live("own-timer", {
            val t = TickText(svc) { fmt(timerAt - System.currentTimeMillis()) }.apply {
                textSize = 14f; setTextColor(AMBER); setTypeface(typeface, Typeface.BOLD)
            }
            Pair(sideViews(label("⏱", 16f, AMBER, true, 1), t), cw(84f))
        }, {
            val root = LinearLayout(svc).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            }
            root.addView(label("⏱ Timer", 14f, AMBER, true, 1))
            root.addView(TickText(svc) { fmt(timerAt - System.currentTimeMillis()) }.apply {
                textSize = 30f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            })
            val row = LinearLayout(svc).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34f)).apply { topMargin = dp(8f) }
            }
            row.addView(pill("+1 mnt") { timerAt += 60_000L; scheduleTimer() })
            row.addView(pill("Batal", Color.parseColor("#7A1F27")) { cancelTimer() })
            root.addView(row)
            Triple(root, 340f, 140f)
        })
        endNow()
    }

    private fun cancelTimer() {
        timerAt = 0L
        handler.removeCallbacks(timerDone)
        try { svc.getSystemService(AlarmManager::class.java).cancel(alarmPi()) } catch (_: Throwable) {}
        if (lives[K_TIMER]?.key == "own-timer") lives.remove(K_TIMER)
        liveExpanded = false
        settle()
    }

    fun timerFinished() {
        handler.post {
            if (timerAt == 0L) return@post
            timerAt = 0L
            handler.removeCallbacks(timerDone)
            if (lives[K_TIMER]?.key == "own-timer") lives.remove(K_TIMER)
            startAlarm()
            val acts = listOf(Act("Stop", false) { stopAlarm() })
            val b = card(null, "Timer selesai", "Waktu habis ⏱", acts, null)
            present(b.first, 340f, b.second, 30000L)
        }
    }

    private fun startAlarm() {
        try {
            val r = RingtoneManager.getRingtone(svc, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            r.play()
            ringtone = r
        } catch (_: Throwable) {}
        try {
            svc.getSystemService(Vibrator::class.java)?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 500, 250, 500, 250, 500), -1))
        } catch (_: Throwable) {}
        handler.postDelayed(stopAlarmR, 25000)
    }

    private fun stopAlarm() {
        handler.removeCallbacks(stopAlarmR)
        try { ringtone?.stop() } catch (_: Throwable) {}
        ringtone = null
        try { svc.getSystemService(Vibrator::class.java)?.cancel() } catch (_: Throwable) {}
    }
}
