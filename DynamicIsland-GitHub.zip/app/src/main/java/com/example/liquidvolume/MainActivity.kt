package com.example.liquidvolume

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E1117")
    private val CARD = Color.parseColor("#161B24")
    private val BLUE = Color.parseColor("#3B82F6")
    private val GREY = Color.parseColor("#A6B0C0")
    private lateinit var cards: List<LinearLayout>
    private lateinit var status: TextView
    private lateinit var primary: Button
    private lateinit var policyBtn: Button
    private lateinit var modeCards: List<LinearLayout>
    private lateinit var shapeCards: List<LinearLayout>
    private lateinit var qualCards: List<LinearLayout>
    private lateinit var recBtn: Button
    private lateinit var listenerBtn: Button
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(x: Int) = (x * d).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun bg(stroke: Boolean): android.graphics.drawable.Drawable =
        if (stroke) Glass.Panel(20 * d, d, BLUE, true, 0x66, 0x38) else Glass.Panel(20 * d, d)

    private fun glassBtn(primaryStyle: Boolean): android.graphics.drawable.Drawable =
        Glass.Panel(28 * d, d, if (primaryStyle) BLUE else 0, primaryStyle)

    private fun tintSwitch(s: Switch) {
        val on = intArrayOf(android.R.attr.state_checked)
        val off = intArrayOf(-android.R.attr.state_checked)
        s.thumbTintList = android.content.res.ColorStateList(arrayOf(on, off),
            intArrayOf(Color.WHITE, Color.parseColor("#D9FFFFFF")))
        s.trackTintList = android.content.res.ColorStateList(arrayOf(on, off),
            intArrayOf(Color.parseColor("#B33B82F6"), Color.parseColor("#33FFFFFF")))
    }

    private fun serviceEnabled() =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    private fun policyGranted() =
        getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Glass.BASE
        window.navigationBarColor = Glass.BASE

        val root = ScrollView(this).apply { background = Glass.Backdrop() }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        root.addView(col)

        col.addView(tv("Alat IOS", 26f, Color.WHITE, true))
        col.addView(tv("Dynamic Island + panel volume iOS Liquid Glass", 14f, GREY).apply { setPadding(0, 0, 0, dp(20)) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun card(title: String, sub: String, style: Int): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(16), dp(12), dp(16))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(5), 0, dp(5), 0) }
                setOnClickListener { Prefs.setStyle(this@MainActivity, style); refresh() }
            }
            val prev = GlassPanelView(this, 0.6f, false).apply { this.style = style; snap(0.6f) }
            val holder = FrameLayout(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#1D4ED8"), Color.parseColor("#0EA5A4"))
                ).apply { cornerRadius = 14 * d }
                addView(prev, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            }
            c.addView(holder, LinearLayout.LayoutParams(-1, -2))
            c.addView(tv(title, 15f, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(2)) })
            c.addView(tv(sub, 12f, GREY).apply { gravity = Gravity.CENTER })
            return c
        }
        cards = listOf(
            card("Blurify", "Tampilan bawaan", Prefs.BLURIFY),
            card("Liquid glass", "Kaca berasap, semua Android", Prefs.LIQUID)
        )
        cards.forEach { row.addView(it) }
        col.addView(row)

        fun switchRow(title: String, sub: String, on: Boolean, enabled: Boolean, cb: (Boolean) -> Unit): LinearLayout {
            val sw = Switch(this).apply {
                isChecked = on; isEnabled = enabled
                tintSwitch(this)
                setOnCheckedChangeListener { _, v -> cb(v) }
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = bg(false)
                setPadding(dp(16), dp(14), dp(16), dp(14))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            }
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(tv(title, 15f, Color.WHITE, true))
                addView(tv(sub, 12f, GREY))
            }
            r.addView(t); r.addView(sw)
            return r
        }
        col.addView(switchRow("Blur latar asli", "Android 11+. Di Android 10 otomatis pakai kaca berasap buatan (tetap liquid glass).",
            Prefs.blur(this), Build.VERSION.SDK_INT >= 30) { Prefs.setBlur(this, it) }.also {
            (it.layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
        })
        col.addView(switchRow("Tombol hening & Jangan ganggu", "Ketuk titik tiga (...) di atas pil volume untuk membuka lonceng dan bulan.",
            Prefs.buttons(this), true) { Prefs.setButtons(this, it) })

        status = tv("", 13f, GREY).apply { setPadding(0, dp(18), 0, dp(8)) }
        col.addView(status)

        fun btn(primaryStyle: Boolean, click: () -> Unit) = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE)
            background = glassBtn(primaryStyle)
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }
            setOnClickListener { click() }
        }
        primary = btn(true) {
            if (!serviceEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else {
                val s = VolumeService.instance
                if (s != null) s.showPanel()
                else Toast.makeText(this, "Layanan sedang dimulai, coba lagi sebentar", Toast.LENGTH_SHORT).show()
            }
        }
        col.addView(primary)

        policyBtn = btn(false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        col.addView(policyBtn)

        col.addView(btn(false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.apply { text = "Atur baterai (agar layanan tidak dimatikan sistem)" })

        col.addView(tv("Rekam layar HD", 20f, Color.WHITE, true).apply { setPadding(0, dp(26), 0, dp(4)) })
        col.addView(tv("Video MP4 disimpan di Movies/AlatIOS. Saat merekam, titik merah + menitan tampil di island.", 12f, GREY))
        val qrow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        fun qCard(title: String, sub: String, v: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
            addView(tv(title, 14f, Color.WHITE, true))
            addView(tv(sub, 11f, GREY))
            setOnClickListener { Prefs.setRecQuality(this@MainActivity, v); refresh() }
        }
        qualCards = listOf(qCard("HD", "720p", 0), qCard("Full HD", "1080p", 1), qCard("Asli", "Resolusi layar", 2))
        qualCards.forEach { qrow.addView(it) }
        col.addView(qrow)
        col.addView(switchRow("Rekam suara mikrofon", "Ikut merekam suara dari mikrofon (butuh izin mikrofon).",
            Prefs.recMic(this), true) { Prefs.setRecMic(this, it) })
        recBtn = btn(true) { startActivity(Intent(this, RecordActivity::class.java)) }
        col.addView(recBtn)
        col.addView(tv("Pengaturan island", 20f, Color.WHITE, true).apply { setPadding(0, dp(26), 0, dp(4)) })
        col.addView(tv("Pil hitam di sekitar kamera depan: notifikasi, musik, telepon, charging, Wi-Fi.", 12f, GREY))
        col.addView(switchRow("Aktifkan Dynamic Island", "Butuh layanan Aksesibilitas aktif.",
            Prefs.islandOn(this), true) { Prefs.setIslandOn(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Pil selalu tampil di kamera", "Pil hitam menetap, melebar saat ada kejadian.",
            Prefs.islandIdle(this), true) { Prefs.setIslandIdle(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Liquid Glass (eksperimen)", "Island jadi kaca; kilau bergeser saat HP dimiringkan.",
            Prefs.islandGlass(this), true) { Prefs.setIslandGlass(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Sembunyikan pop-up notifikasi sistem", "Hanya Dynamic Island yang muncul; notifikasi tetap ada di panel notifikasi (tanpa pop-up).",
            Prefs.hideSys(this), true) { Prefs.setHideSys(this, it) })
        col.addView(tv("Indikator menetap", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, 0) })
        col.addView(switchRow("Indikator charging", "Ikon petir + persen baterai tetap tampil di pil selama HP dicas. Ketuk untuk detail.",
            Prefs.persistCharge(this), true) { Prefs.setPersistCharge(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Kecepatan internet", "Tampilkan kecepatan unduh/unggah langsung di pil.",
            Prefs.speedOn(this), true) { Prefs.setSpeedOn(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Indikator FPS", "Angka frame layar (FPS) tampil di pil, seperti di video referensi.",
            Prefs.fpsOn(this), true) { Prefs.setFpsOn(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Indikator senter", "Saat senter menyala, pil menampilkan ikon senter dan tombol Matikan.",
            Prefs.torchInd(this), true) { Prefs.setTorchInd(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(switchRow("Indikator rekam layar", "Titik merah berkedip + durasi saat merekam layar (butuh akses notifikasi).",
            Prefs.recInd(this), true) { Prefs.setRecInd(this, it); VolumeService.instance?.island?.refresh() })
        col.addView(Button(this).apply {
            text = "Pilih aplikasi perekam layar"; isAllCaps = false; setTextColor(Color.WHITE)
            background = glassBtn(false)
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
            setOnClickListener { pickRecorders() }
        })
        col.addView(tv("Bentuk kamera depan", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, 0) })
        val srow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        fun shapeCard(title: String, sub: String, v: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
            addView(tv(title, 14f, Color.WHITE, true))
            addView(tv(sub, 11f, GREY))
            setOnClickListener { Prefs.setCamShape(this@MainActivity, v); refresh(); VolumeService.instance?.island?.refresh() }
        }
        shapeCards = listOf(
            shapeCard("Otomatis", "Ikuti kamera HP", 0),
            shapeCard("Punchhole kiri", "Lubang di kiri atas", 1),
            shapeCard("Teardrop", "Poni/tetesan air", 2)
        )
        shapeCards.forEach { srow.addView(it) }
        col.addView(srow)
        col.addView(tv("Ukuran & posisi island", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, 0) })
        fun seek(title: String, key: String, lo: Int, hi: Int) {
            val lab = tv("", 13f, Color.WHITE)
            val cur = Prefs.adj(this, key)
            lab.text = "$title: $cur dp"
            val sb = SeekBar(this).apply {
                this.max = hi - lo
                progressTintList = android.content.res.ColorStateList.valueOf(BLUE)
                thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
                progress = cur - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                        val v = p + lo
                        lab.text = "$title: $v dp"
                        if (fromUser) {
                            Prefs.setAdj(this@MainActivity, key, v)
                            VolumeService.instance?.island?.refreshSoon()
                        }
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(false)
                setPadding(dp(16), dp(12), dp(16), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            }
            box.addView(lab)
            box.addView(sb)
            col.addView(box)
        }
        seek("Lebar pil", "dw", -30, 100)
        seek("Tinggi pil", "dh", -8, 16)
        seek("Posisi horizontal", "dx", -160, 160)
        seek("Posisi vertikal", "dy", -20, 80)
        col.addView(Button(this).apply {
            text = "Reset ukuran & posisi"; isAllCaps = false; setTextColor(Color.WHITE)
            background = glassBtn(false)
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) }
            setOnClickListener {
                listOf("dw", "dh", "dx", "dy").forEach { Prefs.setAdj(this@MainActivity, it, 0) }
                VolumeService.instance?.island?.refreshSoon()
                recreate()
            }
        })
        val mrow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        }
        fun modeCard(title: String, sub: String, m: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(5), 0, dp(5), 0) }
            addView(tv(title, 15f, Color.WHITE, true))
            addView(tv(sub, 12f, GREY))
            setOnClickListener { Prefs.setIslandMode(this@MainActivity, m); refresh(); VolumeService.instance?.island?.refresh() }
        }
        modeCards = listOf(
            modeCard("Mode biasa", "Pil hitam, animasi cepat & rapi", 0),
            modeCard("Mode iOS", "Membal seperti iOS + rim cahaya", 1)
        )
        modeCards.forEach { mrow.addView(it) }
        col.addView(mrow)
        listenerBtn = btn(false) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        col.addView(listenerBtn)
        col.addView(btn(false) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 7)
        }.apply { text = "Izinkan lokasi (untuk menampilkan nama Wi-Fi)" })
        col.addView(btn(true) {
            val s = VolumeService.instance
            if (s == null) Toast.makeText(this, "Aktifkan layanan Aksesibilitas dulu", Toast.LENGTH_SHORT).show()
            else s.island?.demo()
        }.apply { text = "Coba Dynamic Island" })

        setContentView(root)
        refresh()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 8)
        }
    }

    private fun pickRecorders() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val sel = HashSet(Prefs.recPkgs(this))
        val checked = BooleanArray(apps.size) { sel.contains(apps[it].first) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Aplikasi perekam layar")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on ->
                if (on) sel.add(apps[i].first) else sel.remove(apps[i].first)
            }
            .setPositiveButton("Simpan") { _, _ ->
                Prefs.setRecPkgs(this, sel)
                VolumeService.instance?.island?.refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onResume() { super.onResume(); if (::cards.isInitialized) refresh() }

    private fun refresh() {
        val cur = Prefs.style(this)
        cards.forEachIndexed { i, c -> c.background = bg(i == cur) }
        val on = serviceEnabled()
        primary.text = if (on) "Coba sekarang" else "Aktifkan layanan (Aksesibilitas)"
        status.text = if (on) "Status: layanan aktif ✓ (tetap aktif walau HP direstart)"
        else "Status: belum aktif. Buka Aksesibilitas → Alat IOS → nyalakan."
        policyBtn.text = if (policyGranted()) "Akses Jangan Ganggu: sudah diizinkan ✓"
        else "Izinkan akses Jangan Ganggu (untuk mode hening & bulan)"
        modeCards.forEachIndexed { i, c -> c.background = bg(i == Prefs.islandMode(this)) }
        shapeCards.forEachIndexed { i, c -> c.background = bg(i == Prefs.camShape(this)) }
        qualCards.forEachIndexed { i, c -> c.background = bg(i == Prefs.recQuality(this)) }
        recBtn.text = if (RecorderService.running) "Hentikan rekam layar" else "Mulai rekam layar"
        val ln = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        listenerBtn.text = if (ln) "Akses notifikasi: sudah diizinkan ✓"
        else "Izinkan akses notifikasi (untuk notifikasi & musik)"
    }
}
