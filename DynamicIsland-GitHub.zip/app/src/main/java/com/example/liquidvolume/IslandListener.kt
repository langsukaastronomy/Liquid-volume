package com.example.liquidvolume

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Menangkap notifikasi + sesi musik untuk Dynamic Island. */
class IslandListener : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private val regs = ArrayList<Pair<MediaController, MediaController.Callback>>()
    private val cn by lazy { ComponentName(this, IslandListener::class.java) }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        try {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            bind(msm?.getActiveSessions(cn))
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Throwable) {}
        clear()
    }

    private fun clear() {
        regs.forEach { try { it.first.unregisterCallback(it.second) } catch (_: Throwable) {} }
        regs.clear()
    }

    private fun bind(list: List<MediaController>?) {
        clear()
        list?.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { pingBest() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { pingBest() }
            }
            try { c.registerCallback(cb); regs.add(Pair(c, cb)) } catch (_: Throwable) {}
        }
        pingBest()
    }

    private fun pingBest() {
        val island = VolumeService.instance?.island ?: return
        val cs = regs.map { it.first }
        val c = cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        if (c == null) island.musicGone()
        else island.musicLive(c, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val island = VolumeService.instance?.island ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val tpl = n.extras.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (tpl.contains("MediaStyle")) return
        val ongoing = sbn.isOngoing
        val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val isCall = n.category == Notification.CATEGORY_CALL
        val isNav = n.category == "navigation" ||
                (ongoing && sbn.packageName == "com.google.android.apps.maps")
        when {
            isNav -> island.navLive(sbn)
            isCall && ongoing && chrono -> island.callLive(sbn)
            isCall -> island.showNotification(sbn, true)
            ongoing && chrono -> island.timerLive(sbn)
            ongoing -> return
            else -> island.showNotification(sbn, false)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        VolumeService.instance?.island?.removeByKey(sbn.key)
    }
}
