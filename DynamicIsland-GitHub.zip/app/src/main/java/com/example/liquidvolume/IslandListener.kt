package com.example.liquidvolume

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Menangkap notifikasi + sesi musik untuk Dynamic Island. */
class IslandListener : NotificationListenerService() {
    private val CH = "island_mirror"
    private val cancelled = HashSet<String>()
    private val seenSig = HashMap<String, Long>()
    private var msm: MediaSessionManager? = null
    private val regs = ArrayList<Pair<MediaController, MediaController.Callback>>()
    private val cn by lazy { ComponentName(this, IslandListener::class.java) }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        try {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            bind(msm?.getActiveSessions(cn))
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Throwable) {}
        clear()
    }

    private fun clear() {
        regs.forEach { try { it.first.unregisterCallback(it.second) } catch (_: Throwable) {} }
        regs.clear()
    }

    private fun bind(list: List<MediaController>?) {
        clear()
        list?.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { pingBest() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { pingBest() }
            }
            try { c.registerCallback(cb); regs.add(Pair(c, cb)) } catch (_: Throwable) {}
        }
        pingBest()
    }

    private fun pingBest() {
        val island = VolumeService.instance?.island ?: return
        val cs = regs.map { it.first }
        val c = cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        if (c == null) island.musicGone()
        else island.musicLive(c, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    /** Tanda pengenal isi notifikasi: dipakai agar isi yang sama tidak tampil/di-salin dua kali. */
    private fun sigOf(sbn: StatusBarNotification): String {
        val ex = sbn.notification.extras
        return sbn.packageName + "|" + ex.getCharSequence(Notification.EXTRA_TITLE) + "|" +
            (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)) + "|" +
            ex.getCharSequence(Notification.EXTRA_SUB_TEXT)
    }

    /** True kalau isi yang sama baru saja tampil (update berulang / posting ganda dari aplikasi). */
    private fun isDup(sig: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        val last = seenSig[sig]
        seenSig[sig] = now
        if (seenSig.size > 60) seenSig.entries.removeAll { now - it.value > 15000L }
        return last != null && now - last < 6000L
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val island = VolumeService.instance?.island ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val tpl = n.extras.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (tpl.contains("MediaStyle")) return
        val ongoing = sbn.isOngoing
        val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val isCall = n.category == Notification.CATEGORY_CALL
        val isNav = n.category == "navigation" ||
                (ongoing && sbn.packageName == "com.google.android.apps.maps")
        when {
            isNav -> island.navLive(sbn)
            isCall && ongoing && chrono -> island.callLive(sbn)
            isCall -> { if (!isDup(sigOf(sbn))) island.showNotification(sbn, true) }
            ongoing && chrono -> island.timerLive(sbn)
            ongoing -> return
            else -> {
                val dup = isDup(sigOf(sbn))
                // salin senyap dulu (notifikasi asli langsung dibatalkan), baru tampilkan di island
                if (Prefs.hideSys(this)) mirror(sbn)
                if (!dup) island.showNotification(sbn, false)
            }
        }
    }

    private fun appLabel(pkg: String): CharSequence = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
    } catch (_: Throwable) { pkg }

    /** Ganti notifikasi asli dengan salinan senyap (tanpa pop-up) supaya tidak dobel dengan Dynamic Island. */
    private fun mirror(sbn: StatusBarNotification) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            val n = sbn.notification
            val si = n.smallIcon ?: return
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "Notifikasi (tanpa pop-up)", NotificationManager.IMPORTANCE_LOW))
            }
            val ex = n.extras
            val b = Notification.Builder(this, CH)
                .setSmallIcon(si)
                .setContentTitle(ex.getCharSequence(Notification.EXTRA_TITLE))
                .setContentText(ex.getCharSequence(Notification.EXTRA_TEXT))
                .setSubText(appLabel(sbn.packageName))
                .setWhen(n.`when`)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
            n.getLargeIcon()?.let { b.setLargeIcon(it) }
            ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.let { b.setStyle(Notification.BigTextStyle().bigText(it)) }
            n.contentIntent?.let { b.setContentIntent(it) }
            n.deleteIntent?.let { b.setDeleteIntent(it) }
            n.actions?.forEach { b.addAction(it) }
            if (n.color != 0) b.setColor(n.color)
            // tag dari isi (bukan key) -> isi yang sama selalu menimpa salinan lama, tidak numpuk dobel
            nm.notify("m" + sigOf(sbn).hashCode(), 0, b.build())
            cancelled.add(sbn.key)
            cancelNotification(sbn.key)
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (cancelled.remove(sbn.key)) return
        VolumeService.instance?.island?.removeByKey(sbn.key)
    }
}
