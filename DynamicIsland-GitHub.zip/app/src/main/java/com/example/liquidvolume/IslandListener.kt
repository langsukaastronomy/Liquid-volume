package com.example.liquidvolume

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Menangkap notifikasi + sesi musik untuk Dynamic Island. */
class IslandListener : NotificationListenerService() {
    private val CH = "island_mirror_min"
    private val cancelled = HashSet<String>()
    private val seenSig = HashMap<String, Long>()
    private val h = Handler(Looper.getMainLooper())

    private fun stillThere(key: String) = try {
        activeNotifications?.any { it.key == key } == true
    } catch (_: Throwable) { false }

    /** Batalkan notifikasi asli dan ulangi sampai benar-benar hilang (sebagian HP gagal kalau dibatalkan sekali). */
    private fun killOriginal(key: String) {
        cancelled.add(key)
        fun once() { try { cancelNotification(key) } catch (_: Throwable) {} }
        once()
        longArrayOf(120L, 400L, 1000L, 2500L).forEach { t ->
            h.postDelayed({ if (stillThere(key)) once() }, t)
        }
        // terakhir, kalau masih bandel: tunda (snooze) supaya pop-up-nya hilang
        h.postDelayed({
            if (stillThere(key)) try { snoozeNotification(key, 6 * 3600_000L) } catch (_: Throwable) {}
        }, 3500L)
        h.postDelayed({
            if (stillThere(key)) VolumeService.instance?.island?.note("Sistem menolak batalkan notif")
        }, 4800L)
    }
    private var msm: MediaSessionManager? = null
    private val regs = ArrayList<Pair<MediaController, MediaController.Callback>>()
    private val cn by lazy { ComponentName(this, IslandListener::class.java) }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        try {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            bind(msm?.getActiveSessions(cn))
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Throwable) {}
        clear()
    }

    private fun clear() {
        regs.forEach { try { it.first.unregisterCallback(it.second) } catch (_: Throwable) {} }
        regs.clear()
    }

    private fun bind(list: List<MediaController>?) {
        clear()
        list?.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { pingBest() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { pingBest() }
            }
            try { c.registerCallback(cb); regs.add(Pair(c, cb)) } catch (_: Throwable) {}
        }
        pingBest()
    }

    private fun pingBest() {
        val island = VolumeService.instance?.island ?: return
        val cs = regs.map { it.first }
        val c = cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        if (c == null) island.musicGone()
        else island.musicLive(c, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    /** Tanda pengenal isi notifikasi: dipakai agar isi yang sama tidak tampil/di-salin dua kali. */
    private fun sigOf(sbn: StatusBarNotification): String {
        val ex = sbn.notification.extras
        return sbn.packageName + "|" + ex.getCharSequence(Notification.EXTRA_TITLE) + "|" +
            (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)) + "|" +
            ex.getCharSequence(Notification.EXTRA_SUB_TEXT)
    }

    /** True kalau isi yang sama baru saja tampil (update berulang / posting ganda dari aplikasi). */
    private fun isDup(sig: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        val last = seenSig[sig]
        seenSig[sig] = now
        if (seenSig.size > 60) seenSig.entries.removeAll { now - it.value > 15000L }
        return last != null && now - last < 6000L
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val island = VolumeService.instance?.island ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            // ringkasan grup juga memunculkan pop-up sistem -> batalkan, tanpa kartu Island
            if (Prefs.hideSys(this)) killOriginal(sbn.key)
            return
        }
        val tpl = n.extras.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (tpl.contains("MediaStyle")) return
        val ongoing = sbn.isOngoing
        val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val isCall = n.category == Notification.CATEGORY_CALL
        val isNav = n.category == "navigation" ||
                (ongoing && sbn.packageName == "com.google.android.apps.maps")
        when {
            isNav -> island.navLive(sbn)
            isCall && ongoing && chrono -> island.callLive(sbn)
            isCall -> { if (!isDup(sigOf(sbn))) island.showNotification(sbn, true) }
            ongoing && chrono -> island.timerLive(sbn)
            ongoing -> return
            else -> {
                val dup = isDup(sigOf(sbn))
                // salin senyap dulu (notifikasi asli langsung dibatalkan), baru tampilkan di island
                if (Prefs.hideSys(this)) mirror(sbn, if (dup || !Prefs.islandOn(this)) 0L else 5400L)
                if (!dup) island.showNotification(sbn, false)
            }
        }
    }

    private fun appLabel(pkg: String): CharSequence = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
    } catch (_: Throwable) { pkg }

    /** Batalkan notifikasi asli DULU (apa pun yang terjadi), lalu pasang salinan senyap tanpa pop-up. */
    private fun mirror(sbn: StatusBarNotification, delayMs: Long) {
        killOriginal(sbn.key)
        // salinan di panel notifikasi baru muncul setelah kartu Island selesai (Island dulu, baru sistem)
        h.postDelayed({ postCopy(sbn) }, delayMs)
    }

    private fun postCopy(sbn: StatusBarNotification) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            val n = sbn.notification
            val si = n.smallIcon ?: return
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "Notifikasi (tanpa pop-up)", NotificationManager.IMPORTANCE_MIN).apply {
                        setSound(null, null); enableVibration(false); setShowBadge(false)
                    })
            }
            val ex = n.extras
            val b = Notification.Builder(this, CH)
                .setSmallIcon(si)
                .setContentTitle(ex.getCharSequence(Notification.EXTRA_TITLE))
                .setContentText(ex.getCharSequence(Notification.EXTRA_TEXT))
                .setSubText(appLabel(sbn.packageName))
                .setWhen(n.`when`)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setGroupAlertBehavior(Notification.GROUP_ALERT_SUMMARY)
            try { n.getLargeIcon()?.let { b.setLargeIcon(it) } } catch (_: Throwable) {}
            try { ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.let { b.setStyle(Notification.BigTextStyle().bigText(it)) } } catch (_: Throwable) {}
            try { n.contentIntent?.let { b.setContentIntent(it) } } catch (_: Throwable) {}
            try { n.deleteIntent?.let { b.setDeleteIntent(it) } } catch (_: Throwable) {}
            try { n.actions?.forEach { b.addAction(it) } } catch (_: Throwable) {}
            if (n.color != 0) b.setColor(n.color)
            nm.notify("m" + sigOf(sbn).hashCode(), 0, b.build())
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (cancelled.remove(sbn.key)) return
        VolumeService.instance?.island?.removeByKey(sbn.key)
    }
}
