package com.example.liquidvolume

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Menangkap notifikasi + sesi musik untuk Dynamic Island. */
class IslandListener : NotificationListenerService() {
    private val CH = "island_mirror"
    private val cancelled = HashSet<String>()
    private var msm: MediaSessionManager? = null
    private val regs = ArrayList<Pair<MediaController, MediaController.Callback>>()
    private val cn by lazy { ComponentName(this, IslandListener::class.java) }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        try {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            bind(msm?.getActiveSessions(cn))
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Throwable) {}
        clear()
    }

    private fun clear() {
        regs.forEach { try { it.first.unregisterCallback(it.second) } catch (_: Throwable) {} }
        regs.clear()
    }

    private fun bind(list: List<MediaController>?) {
        clear()
        list?.forEach { c ->
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { pingBest() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { pingBest() }
            }
            try { c.registerCallback(cb); regs.add(Pair(c, cb)) } catch (_: Throwable) {}
        }
        pingBest()
    }

    private fun pingBest() {
        val island = VolumeService.instance?.island ?: return
        val cs = regs.map { it.first }
        val c = cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        if (c == null) island.musicGone()
        else island.musicLive(c, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val island = VolumeService.instance?.island ?: return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val tpl = n.extras.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (tpl.contains("MediaStyle")) return
        val ongoing = sbn.isOngoing
        val chrono = n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val isCall = n.category == Notification.CATEGORY_CALL
        val isNav = n.category == "navigation" ||
                (ongoing && sbn.packageName == "com.google.android.apps.maps")
        when {
            isNav -> island.navLive(sbn)
            isCall && ongoing && chrono -> island.callLive(sbn)
            isCall -> island.showNotification(sbn, true)
            ongoing && chrono -> island.timerLive(sbn)
            ongoing -> return
            else -> {
                island.showNotification(sbn, false)
                if (Prefs.hideSys(this)) mirror(sbn)
            }
        }
    }

    private fun appLabel(pkg: String): CharSequence = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
    } catch (_: Throwable) { pkg }

    /** Ganti notifikasi asli dengan salinan senyap (tanpa pop-up) supaya tidak dobel dengan Dynamic Island. */
    private fun mirror(sbn: StatusBarNotification) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.areNotificationsEnabled()) return
            val n = sbn.notification
            val si = n.smallIcon ?: return
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "Notifikasi (tanpa pop-up)", NotificationManager.IMPORTANCE_LOW))
            }
            val ex = n.extras
            val b = Notification.Builder(this, CH)
                .setSmallIcon(si)
                .setContentTitle(ex.getCharSequence(Notification.EXTRA_TITLE))
                .setContentText(ex.getCharSequence(Notification.EXTRA_TEXT))
                .setSubText(appLabel(sbn.packageName))
                .setWhen(n.`when`)
                .setShowWhen(true)
                .setAutoCancel(true)
            n.getLargeIcon()?.let { b.setLargeIcon(it) }
            ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.let { b.setStyle(Notification.BigTextStyle().bigText(it)) }
            n.contentIntent?.let { b.setContentIntent(it) }
            n.deleteIntent?.let { b.setDeleteIntent(it) }
            n.actions?.forEach { b.addAction(it) }
            if (n.color != 0) b.setColor(n.color)
            nm.notify(sbn.key, 0, b.build())
            cancelled.add(sbn.key)
            cancelNotification(sbn.key)
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (cancelled.remove(sbn.key)) return
        VolumeService.instance?.island?.removeByKey(sbn.key)
    }
}
