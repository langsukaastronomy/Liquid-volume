package com.example.liquidvolume

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Perekam layar HD bawaan Alat IOS: video MP4 tersimpan di Movies/AlatIOS. */
class RecorderService : Service() {
    companion object {
        const val CH = "rec"
        const val ACT_STOP = "stop"
        const val ACT_PAUSE = "pause"
        @Volatile var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var mr: MediaRecorder? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var finished = false
    private var paused = false
    private var elapsedBefore = 0L
    private var segStart = 0L

    private fun elapsed() = elapsedBefore + if (paused) 0L else System.currentTimeMillis() - segStart

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACT_STOP) { finish(true); return START_NOT_STICKY }
        if (i?.action == ACT_PAUSE) { togglePause(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        val mic = i?.getBooleanExtra("mic", false) ?: false
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        startFg()
        try {
            begin(code, data, mic)
            running = true
        } catch (t: Throwable) {
            Toast.makeText(this, "Gagal mulai rekam: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
            finish(false)
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "Rekam layar", NotificationManager.IMPORTANCE_LOW).apply {
                setSound(null, null); enableVibration(false); setShowBadge(false)
            })
        }
        segStart = System.currentTimeMillis()
        elapsedBefore = 0L
        val n = buildNotif()
        startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun buildNotif(): Notification {
        fun pi(code: Int, act: String) = PendingIntent.getService(this, code,
            Intent(this, RecorderService::class.java).setAction(act),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val el = elapsed()
        val extras = android.os.Bundle().apply { putBoolean("paused", paused); putLong("elapsed", el) }
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.presence_video_busy)
            .setContentTitle(if (paused) "Rekaman dijeda" else "Merekam layar")
            .setContentText("Ketuk Stop untuk menyimpan video")
            .setWhen(System.currentTimeMillis() - el)
            .setUsesChronometer(!paused)
            .setOngoing(true)
            .addExtras(extras)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this,
                if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause),
                if (paused) "Lanjut" else "Jeda", pi(6, ACT_PAUSE)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Stop", pi(5, ACT_STOP)).build())
            .build()
    }

    private fun togglePause() {
        val r = mr ?: return
        if (!running) return
        try {
            if (paused) { r.resume(); segStart = System.currentTimeMillis(); paused = false }
            else { r.pause(); elapsedBefore += System.currentTimeMillis() - segStart; paused = true }
        } catch (_: Throwable) { return }
        try { getSystemService(NotificationManager::class.java).notify(77, buildNotif()) } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    private fun begin(code: Int, data: Intent, mic: Boolean) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        var w = dm.widthPixels
        var hh = dm.heightPixels
        val shortSide = minOf(w, hh)
        val target = when (Prefs.recQuality(this)) { 0 -> 720; 1 -> 1080; else -> shortSide }
        val bitrate = when (Prefs.recQuality(this)) { 0 -> 6_000_000; 1 -> 10_000_000; else -> 12_000_000 }
        if (target < shortSide) {
            val f = target.toFloat() / shortSide
            w = (w * f).toInt(); hh = (hh * f).toInt()
        }
        w = w and 1.inv(); hh = hh and 1.inv()

        val name = "AlatIOS_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AlatIOS")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("Tidak bisa membuat file")
        uri = u
        val p = contentResolver.openFileDescriptor(u, "w") ?: throw IllegalStateException("Tidak bisa menulis file")
        pfd = p

        val r = MediaRecorder()
        mr = r
        if (mic) r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        if (mic) {
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44100)
        }
        r.setVideoSize(w, hh)
        r.setVideoFrameRate(30)
        r.setVideoEncodingBitRate(bitrate)
        r.setOutputFile(p.fileDescriptor)
        r.prepare()

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        proj = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { h.post { finish(true) } }
        }, h)
        vd = mp.createVirtualDisplay("alatios-rec", w, hh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        r.start()
    }

    private fun finish(save: Boolean) {
        if (finished) return
        finished = true
        running = false
        var ok = save
        try { mr?.stop() } catch (_: Throwable) { ok = false }
        try { mr?.release() } catch (_: Throwable) {}
        try { vd?.release() } catch (_: Throwable) {}
        try { proj?.stop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        val u = uri
        if (u != null) {
            try {
                if (ok) {
                    contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                } else contentResolver.delete(u, null, null)
            } catch (_: Throwable) {}
        }
        if (ok) Toast.makeText(this, "Rekaman tersimpan di Movies/AlatIOS", Toast.LENGTH_LONG).show()
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        if (!finished) finish(true)
        super.onDestroy()
    }
}
