plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.liquidvolume"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.liquidvolume"
        minSdk = 29          // Android 10
        targetSdk = 34
        versionCode = 9
        versionName = "4.4"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
}
