package com.example.liquidvolume

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

class VolumeService : AccessibilityService() {
    companion object { var instance: VolumeService? = null }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private var view: GlassSliderView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val hide = Runnable { hidePanel() }
    private val d get() = resources.displayMetrics.density

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(hide)
        hidePanel()
        super.onDestroy()
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (ev.action == KeyEvent.ACTION_DOWN) {
            am.adjustStreamVolume(
                stream(),
                if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0 // tanpa FLAG_SHOW_UI -> panel bawaan tidak muncul
            )
            showPanel()
        }
        return true
    }

    private fun stream() =
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)
            AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    private fun minVol(s: Int) = if (Build.VERSION.SDK_INT >= 28) am.getStreamMinVolume(s) else 0

    private fun level(): Float {
        val s = stream()
        val min = minVol(s)
        val span = (am.getStreamMaxVolume(s) - min).coerceAtLeast(1)
        return (am.getStreamVolume(s) - min).toFloat() / span
    }

    private fun setLevel(p: Float) {
        val s = stream()
        val min = minVol(s)
        val max = am.getStreamMaxVolume(s)
        am.setStreamVolume(s, (min + p * (max - min)).roundToInt(), 0)
    }

    @Suppress("DEPRECATION")
    fun showPanel() {
        if (!::wm.isInitialized) return
        handler.removeCallbacks(hide)
        var v = view
        if (v == null) {
            v = GlassSliderView(this)
            v.onChange = { p ->
                setLevel(p)
                handler.removeCallbacks(hide)
                handler.postDelayed(hide, 2000)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
            lp.x = (10 * d).toInt()
            if (Build.VERSION.SDK_INT >= 31 && Prefs.realBlur(this)) {
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                lp.blurBehindRadius = 50
            }
            v.alpha = 0f
            v.translationX = 40 * d
            try { wm.addView(v, lp) } catch (_: Exception) { return }
            view = v
            v.animate().alpha(1f).translationX(0f).setDuration(220).start()
        }
        v.style = Prefs.style(this)
        v.progress = level()
        handler.postDelayed(hide, 2000)
    }

    private fun hidePanel() {
        val v = view ?: return
        view = null
        v.animate().alpha(0f).translationX(40 * d).setDuration(180).withEndAction {
            try { wm.removeView(v) } catch (_: Exception) {}
        }.start()
    }
}
