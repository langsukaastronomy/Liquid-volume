package com.example.liquidvolume

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.max
import kotlin.math.roundToInt

class VolumeService : AccessibilityService() {
    companion object { var instance: VolumeService? = null }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var nm: NotificationManager
    private var view: GlassPanelView? = null
    private var pending = false
    private var cache: Bitmap? = null
    private var cacheW = 0
    private var cacheH = 0
    private var cacheAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val hide = Runnable { hidePanel() }
    private val d get() = resources.displayMetrics.density

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        nm = getSystemService(NotificationManager::class.java)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(hide)
        hidePanel()
        super.onDestroy()
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (ev.action == KeyEvent.ACTION_DOWN) {
            am.adjustStreamVolume(
                stream(),
                if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0 // tanpa FLAG_SHOW_UI -> panel bawaan tidak muncul
            )
            showPanel()
        }
        return true
    }

    private fun stream() =
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION)
            AudioManager.STREAM_VOICE_CALL else AudioManager.STREAM_MUSIC

    private fun minVol(s: Int) = if (Build.VERSION.SDK_INT >= 28) am.getStreamMinVolume(s) else 0

    private fun level(): Float {
        val s = stream()
        val min = minVol(s)
        val span = (am.getStreamMaxVolume(s) - min).coerceAtLeast(1)
        return (am.getStreamVolume(s) - min).toFloat() / span
    }

    private fun setLevel(p: Float) {
        val s = stream()
        val min = minVol(s)
        val max = am.getStreamMaxVolume(s)
        am.setStreamVolume(s, (min + p * (max - min)).roundToInt(), 0)
    }

    private fun dndOn() = try {
        nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    } catch (_: Throwable) { false }

    private fun keepAlive() {
        handler.removeCallbacks(hide)
        handler.postDelayed(hide, 2200)
    }

    fun showPanel() {
        if (!::wm.isInitialized) return
        val v = view
        if (v != null) {
            v.style = Prefs.style(this)
            v.ringer = am.ringerMode
            v.dnd = dndOn()
            v.setLevel(level())
            keepAlive()
            return
        }
        if (pending) return
        if (Build.VERSION.SDK_INT >= 30 && Prefs.blur(this)) {
            pending = true
            var done = false
            val finish = { bmp: Bitmap?, w: Int, h: Int ->
                if (!done) { done = true; pending = false; create(bmp, w, h) }
            }
            handler.postDelayed({ finish(null, 0, 0) }, 300)
            capture { bmp, w, h -> finish(bmp, w, h) }
        } else {
            create(null, 0, 0)
        }
    }

    @RequiresApi(30)
    private fun capture(cb: (Bitmap?, Int, Int) -> Unit) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        var out: Bitmap? = null
                        var w = 0
                        var h = 0
                        try {
                            val hb = r.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            if (hw != null) {
                                w = hw.width; h = hw.height
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                if (soft != null) {
                                    val small = Bitmap.createScaledBitmap(soft, max(1, w / 6), max(1, h / 6), true)
                                    soft.recycle()
                                    out = Blur.box(small, 1, 2)
                                    small.recycle()
                                }
                            }
                            hb.close()
                        } catch (_: Throwable) {}
                        cb(out, w, h)
                    }
                    override fun onFailure(errorCode: Int) { cb(null, 0, 0) }
                })
        } catch (_: Throwable) { cb(null, 0, 0) }
    }

    private fun create(bmp: Bitmap?, w: Int, h: Int) {
        if (view != null) return
        val now = System.currentTimeMillis()
        var b = bmp
        var bw = w
        var bh = h
        if (b != null) { cache = b; cacheW = w; cacheH = h; cacheAt = now }
        else if (cache != null && now - cacheAt < 1500) { b = cache; bw = cacheW; bh = cacheH }

        val v = GlassPanelView(this, 1f, Prefs.buttons(this))
        v.style = Prefs.style(this)
        v.backdrop = b; v.bdW = max(1, bw); v.bdH = max(1, bh)
        v.snap(level())
        v.ringer = am.ringerMode
        v.dnd = dndOn()
        v.onActivity = { keepAlive() }
        v.onSlide = { p -> setLevel(p) }
        v.onBell = { onBell() }
        v.onMoon = { onMoon() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        lp.x = (2 * d).toInt()

        v.alpha = 0f
        v.scaleX = 0.8f; v.scaleY = 0.8f
        v.translationX = 28 * d
        try { wm.addView(v, lp) } catch (_: Exception) { return }
        view = v

        fun spring(p: DynamicAnimation.ViewProperty, to: Float) =
            SpringAnimation(v, p, to).apply {
                spring.stiffness = 380f
                spring.dampingRatio = 0.62f
            }.start()
        spring(DynamicAnimation.SCALE_X, 1f)
        spring(DynamicAnimation.SCALE_Y, 1f)
        spring(DynamicAnimation.TRANSLATION_X, 0f)
        v.animate().alpha(1f).setDuration(150).start()
        keepAlive()
    }

    private fun onBell() {
        val v = view ?: return
        try {
            val granted = nm.isNotificationPolicyAccessGranted
            am.ringerMode = when (am.ringerMode) {
                AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                AudioManager.RINGER_MODE_VIBRATE ->
                    if (granted) AudioManager.RINGER_MODE_SILENT else {
                        Toast.makeText(this, "Izinkan akses Jangan Ganggu di app untuk mode hening", Toast.LENGTH_SHORT).show()
                        AudioManager.RINGER_MODE_NORMAL
                    }
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (_: SecurityException) { askPolicy() }
        v.ringer = am.ringerMode
    }

    private fun onMoon() {
        val v = view ?: return
        try {
            if (!nm.isNotificationPolicyAccessGranted) { askPolicy(); return }
            val on = dndOn()
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_ALL
                else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            )
            v.dnd = !on
        } catch (_: Throwable) { askPolicy() }
    }

    private fun askPolicy() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {}
    }

    private fun hidePanel() {
        val v = view ?: return
        view = null
        v.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).translationX(20 * d).setDuration(200)
            .withEndAction { try { wm.removeView(v) } catch (_: Exception) {} }
            .start()
    }
}
