package com.example.liquidvolume

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E1117")
    private val CARD = Color.parseColor("#161B24")
    private val BLUE = Color.parseColor("#3B82F6")
    private lateinit var cards: List<LinearLayout>
    private lateinit var status: TextView
    private val d by lazy { resources.displayMetrics.density }
    private fun dp(x: Int) = (x * d).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun bg(stroke: Boolean) = GradientDrawable().apply {
        cornerRadius = 20 * d
        setColor(CARD)
        if (stroke) setStroke(dp(2), BLUE)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = ScrollView(this).apply { setBackgroundColor(BG) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        root.addView(col)

        col.addView(tv("Liquid Volume", 26f, Color.WHITE, true))
        col.addView(tv("Panel volume bergaya iOS Liquid Glass", 14f, Color.parseColor("#9AA4B2")).apply {
            setPadding(0, 0, 0, dp(20))
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun card(title: String, sub: String, style: Int): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(12), dp(16), dp(12), dp(16))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(dp(5), 0, dp(5), 0) }
                setOnClickListener { Prefs.setStyle(this@MainActivity, style); refresh() }
            }
            val prev = GlassSliderView(this).apply {
                this.style = style; widthDp = 30; heightDp = 100; progress = 0.6f
            }
            val holder = FrameLayout(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#1D4ED8"), Color.parseColor("#0EA5A4"))
                ).apply { cornerRadius = 14 * d }
                setPadding(dp(30), dp(10), dp(30), dp(10))
                addView(prev)
            }
            c.addView(holder)
            c.addView(tv(title, 15f, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(2)) })
            c.addView(tv(sub, 12f, Color.parseColor("#9AA4B2")).apply { gravity = Gravity.CENTER })
            return c
        }
        cards = listOf(
            card("Blurify", "Tampilan frosted bawaan", Prefs.BLURIFY),
            card("Liquid glass", "Kaca berasap + kilau specular", Prefs.LIQUID)
        )
        cards.forEach { row.addView(it) }
        col.addView(row)

        val sw = Switch(this).apply {
            isChecked = Prefs.realBlur(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setRealBlur(this@MainActivity, on) }
            isEnabled = android.os.Build.VERSION.SDK_INT >= 31
        }
        val blurRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg(false)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        }
        val txt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(tv("Blur asli di belakang panel", 15f, Color.WHITE, true))
            addView(tv("Android 12+ (eksperimental). Di Android 10-11 otomatis pakai kaca transparan.", 12f, Color.parseColor("#9AA4B2")))
        }
        blurRow.addView(txt); blurRow.addView(sw)
        col.addView(blurRow)

        status = tv("", 13f, Color.parseColor("#9AA4B2")).apply { setPadding(0, dp(18), 0, dp(8)) }
        col.addView(status)

        fun btn(t: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(if (primary) BLUE else CARD)
            }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }
            setOnClickListener { click() }
        }
        col.addView(btn("Aktifkan layanan (Aksesibilitas)", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("Coba panel volume", false) {
            val s = VolumeService.instance
            if (s == null) Toast.makeText(this, "Aktifkan layanan dulu", Toast.LENGTH_SHORT).show()
            else s.showPanel()
        })

        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); if (::cards.isInitialized) refresh() }

    private fun refresh() {
        val cur = Prefs.style(this)
        cards.forEachIndexed { i, c -> c.background = bg(i == cur) }
        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        status.text = if (on) "Status: layanan aktif ✓" else
            "Status: belum aktif. Buka Aksesibilitas → Liquid Volume → nyalakan."
    }
}
