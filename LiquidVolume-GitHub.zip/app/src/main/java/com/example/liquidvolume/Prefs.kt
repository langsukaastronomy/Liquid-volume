package com.example.liquidvolume

import android.content.Context

object Prefs {
    const val BLURIFY = 0
    const val LIQUID = 1
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun style(c: Context) = sp(c).getInt("style", LIQUID)
    fun setStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun realBlur(c: Context) = sp(c).getBoolean("blur", false)
    fun setRealBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean("blur", v).apply()
}
