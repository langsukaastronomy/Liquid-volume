package com.example.liquidvolume

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** Slider vertikal berbentuk pil: kaca berasap + isi putih + rim highlight + kilau specular. */
class GlassSliderView(ctx: Context) : View(ctx) {
    var style = Prefs.LIQUID
        set(v) { field = v; invalidate() }
    var progress = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var widthDp = 58
    var heightDp = 230
    var onChange: ((Float) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
    }
    private val clip = Path()
    private val rect = RectF()

    private val smokeTop = Color.parseColor("#992A3342")
    private val smokeBot = Color.parseColor("#66141A24")
    private val frostTop = Color.parseColor("#66FFFFFF")
    private val frostBot = Color.parseColor("#33FFFFFF")

    override fun onMeasure(w: Int, h: Int) =
        setMeasuredDimension((widthDp * d).toInt(), (heightDp * d).toInt())

    override fun onDraw(c: Canvas) {
        val inset = 1.5f * d
        rect.set(inset, inset, width - inset, height - inset)
        val r = rect.width() / 2f
        val h = height.toFloat()

        fill.shader = if (style == Prefs.LIQUID)
            LinearGradient(0f, 0f, 0f, h, smokeTop, smokeBot, Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, 0f, 0f, h, frostTop, frostBot, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, fill)

        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val top = rect.bottom - rect.height() * progress
        fill.shader = null
        fill.color = Color.parseColor(if (style == Prefs.LIQUID) "#E6FFFFFF" else "#F2FFFFFF")
        c.drawRect(rect.left, top, rect.right, rect.bottom, fill)

        if (style == Prefs.LIQUID) {
            fill.shader = RadialGradient(
                rect.centerX() - rect.width() * 0.2f, rect.top + rect.height() * 0.12f,
                rect.width() * 0.9f,
                Color.parseColor("#66FFFFFF"), Color.parseColor("#00FFFFFF"),
                Shader.TileMode.CLAMP
            )
            c.drawRect(rect, fill)
            fill.shader = null
        }
        c.restore()

        rim.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(Color.parseColor("#CCFFFFFF"), Color.parseColor("#1AFFFFFF"), Color.parseColor("#99FFFFFF")),
            null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, r, r, rim)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            parent?.requestDisallowInterceptTouchEvent(true)
            progress = 1f - (e.y - rect.top) / rect.height()
            onChange?.invoke(progress)
        }
        return true
    }
}
